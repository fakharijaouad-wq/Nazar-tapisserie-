import { db } from "@/db";
import { products, siteSettings, reviews, quoteRequests } from "@/db/schema";
import { sql } from "drizzle-orm";

let isSeeding = false;

export async function ensureDbSeeded() {
  if (isSeeding) return;
  try {
    isSeeding = true;
    const countResult = await db.select({ count: sql<number>`count(*)` }).from(products);
    const count = Number(countResult[0]?.count ?? 0);

    if (count === 0) {
      console.log("Seeding database with Nazaré Tapisserie initial data...");
      
      // 1. Site settings
      const settingsCount = await db.select({ count: sql<number>`count(*)` }).from(siteSettings);
      if (Number(settingsCount[0]?.count ?? 0) === 0) {
        await db.insert(siteSettings).values({
          companyName: "Nazaré Tapisserie",
          phone: "0631363887",
          email: "fakharijaouad@gmail.com",
          address: "المغرب - ورشات الصنعة الرفيعة والتوصيل والتركيب لجميع المدن",
          announcement: "✨ تفصيل حسب المقاس والطلب مع ضمان 5 سنوات وتوصيل وتركيب مجاني في جميع أنحاء المغرب ✨",
          workingHours: "طيلة أيام الأسبوع من 9:00 صباحاً حتى 20:30 مساءً",
          heroTitle: "صناعة وتنجيد المفروشات المنزلية الفاخرة والكنبات وغرف النوم",
          heroSubtitle: "شركة Nazaré Tapisserie متخصصة في صناعة وتنجيد الكنبات العصرية، غرف النوم الماستر، غرف نوم الأطفال، كراسي طاولات الطعام وكراسي الصالونات بأجود أنواع خشب الزان وأرقى الأقمشة الإيطالية والتركية.",
        });
      }

      // 2. Initial products
      await db.insert(products).values([
        // Sofas
        {
          title: "صالون نازاري الملكي الفاخر (L-Shape)",
          titleFr: "Salon Nazaré Royal Angle Velvet",
          slug: "salon-nazare-royal-velvet",
          category: "sofas",
          categoryNameAr: "الكنبات والصالونات",
          price: 6800,
          originalPrice: 8500,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/8135267/pexels-photo-8135267.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "صالون زاوية فخم ومريح بتصميم عصري يناسب كافة المساحات. هيكل متين مصنوع من خشب الزان الأحمر الرومي، حشوة إسفنج طبي عالي الكثافة (D30/D33) لضمان الراحة الدائمة، وقماش مخمل إيطالي ناعم ومقاوم للبقع والماء.",
          woodType: "خشب الزان الأحمر الصلب (Hêtre Rouge)",
          fabricType: "مخمل إيطالي ناعم مقاوم للبقع (Anti-taches)",
          dimensions: "320 سم × 240 سم (متاح تفصيل حسب مقاس صالونك)",
          warrantyYears: 5,
          isFeatured: true,
          badge: "الأكثر طلباً",
        },
        {
          title: "طقم كنب عصري كامل 3+2+1",
          titleFr: "Ensemble Salon Moderne 3+2+1",
          slug: "ensemble-salon-moderne-3-2-1",
          category: "sofas",
          categoryNameAr: "الكنبات والصالونات",
          price: 8200,
          originalPrice: 10500,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/8135496/pexels-photo-8135496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "طقم كنب عائلي متكامل يضم كنبة ثلاثية، كنبة ثنائية وكرسي مفرد مريح. تفصيل يدوي دقيق مع وسائد زخرفية متناسقة، أرجل خشبية أو ستانلس ستيل مذهبة حسب الاختيار.",
          woodType: "هيكل خشبي معالج بالكامل من خشب الزان",
          fabricType: "قماش كتان معالج مقاوم للتلف وسهل التنظيف",
          dimensions: "ثلاثية: 220 سم | ثنائية: 170 سم | مفرد: 90 سم",
          warrantyYears: 5,
          isFeatured: true,
          badge: "طقم متكامل",
        },
        {
          title: "صالون مغربي عصري كابيتوني راقي",
          titleFr: "Salon Marocain Contemporain Nazaré",
          slug: "salon-marocain-contemporain",
          category: "sofas",
          categoryNameAr: "الكنبات والصالونات",
          price: 9500,
          originalPrice: 12000,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/8135267/pexels-photo-8135267.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/8135267/pexels-photo-8135267.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7174113/pexels-photo-7174113.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "مزيج متناغم يجمع بين أصالة الصالون المغربي وحداثة التصميم الأوروبي. مقاعد سداري مبطنة بأعلى مستويات الجودة، مساند ظهر كابيتوني فاخرة وخياطة متقنة.",
          woodType: "خشب صلب عالي الجودة مع تشطيب يدوي نقي",
          fabricType: "أقمشة صالونات تركية ومغربية راقية ومقاومة",
          dimensions: "تفصيل حسب مقاسات الصالون بالمتر",
          warrantyYears: 5,
          isFeatured: false,
          badge: "تصميم حصري",
        },
        // Bedrooms
        {
          title: "غرفة نوم ماستر ملكية Nazaré Suite",
          titleFr: "Chambre à Coucher Master Royale",
          slug: "chambre-master-royale-nazare",
          category: "bedrooms",
          categoryNameAr: "غرف النوم",
          price: 11500,
          originalPrice: 14000,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/39955909/pexels-photo-39955909.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/39955909/pexels-photo-39955909.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7546291/pexels-photo-7546291.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7546275/pexels-photo-7546275.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "غرفة نوم ماستر فاخرة تشمل سريراً مريحاً بخلفية سرير مبطنة ومزخرفة (Tête de lit capitonnée)، طاولة تزيين (Coiffeuse) عصرية مع مرآة ذكية، وكومودينات جانبية متناسقة مع إضاءات خفية.",
          woodType: "خشب السنديان مع زان أحمر متين",
          fabricType: "مخمل بوكلي أو كتان طبيعي عالي الجودة",
          dimensions: "سرير 180 × 200 سم أو 160 × 200 سم",
          warrantyYears: 5,
          isFeatured: true,
          badge: "غرفة كاملة",
        },
        {
          title: "سرير كابيتوني فندقي فاخر مع قاعدة خشبية",
          titleFr: "Lit Prestige Capitonnée Hôtelier",
          slug: "lit-prestige-capitonnee",
          category: "bedrooms",
          categoryNameAr: "غرف النوم",
          price: 4900,
          originalPrice: 6200,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/7546291/pexels-photo-7546291.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/7546291/pexels-photo-7546291.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7546556/pexels-photo-7546556.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "سرير مودرن مستوحى من أجنحة الفنادق العالمية 5 نجوم. رأس سرير عريض ومبطن يمتد خلف الكومودين مع أزرار كابيتوني غائرة وقاعدة سرير متينة تمنح ثباتاً فائقاً.",
          woodType: "خشب زان وقاعدة سميكة مدعمة",
          fabricType: "قماش سويدي / مخمل ناعم متوفر بأكثر من 40 لون",
          dimensions: "160 × 200 سم / 180 × 200 سم / 200 × 200 سم",
          warrantyYears: 5,
          isFeatured: false,
          badge: "مريح جداً",
        },
        {
          title: "غرفة نوم مينيمالست عصرية بتخزين ذكي (Lit Coffre)",
          titleFr: "Chambre Minimaliste Coffre Nazaré",
          slug: "chambre-minimaliste-moderne",
          category: "bedrooms",
          categoryNameAr: "غرف النوم",
          price: 9800,
          originalPrice: 11900,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/7546275/pexels-photo-7546275.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/7546275/pexels-photo-7546275.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7722153/pexels-photo-7722153.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "تصميم عصري بسيط وأنيق يوفر الراحة والهدوء، مع صندوق تخزين هيدروليكي أسفل السرير (Lit coffre) لحفظ الأغطية والملابس بكل سلاسة وأمان.",
          woodType: "خشب طبيعي مطلي بطبقة حماية مقاومة للرطوبة والخدش",
          fabricType: "كتان إيطالي نقي ناعم الملمس",
          dimensions: "160 × 200 سم + 2 كومودين",
          warrantyYears: 5,
          isFeatured: false,
          badge: "تخزين هيدروليكي",
        },
        // Kids Bedrooms
        {
          title: "غرفة نوم أطفال متكاملة Nazaré Joy",
          titleFr: "Chambre Enfant Complète Nazaré Joy",
          slug: "chambre-enfant-complete-nazare-joy",
          category: "kids_bedrooms",
          categoryNameAr: "غرف نوم الأطفال",
          price: 6900,
          originalPrice: 8500,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/6670652/pexels-photo-6670652.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6670652/pexels-photo-6670652.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7587803/pexels-photo-7587803.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "غرفة نوم أطفال مصممة بعناية فائقة لتوفير بيئة نوم ولعب آمنة ومبهجة. تتضمن سريراً مريحاً بزوايا دائرية، مكتب دراسي، وخزانة ملابس منظمة وجميلة بألوان مهدئة.",
          woodType: "خشب زان مع ألواح MDF صديقة للبيئة وخالية من الروائح",
          fabricType: "قماش مبطن ومقاوم للبقع وسهل المسح",
          dimensions: "سرير 100 × 190 سم أو 120 × 200 سم",
          warrantyYears: 5,
          isFeatured: true,
          badge: "آمن للأطفال",
        },
        {
          title: "سرير أطفال مبطن مزدوج (Twin Beds)",
          titleFr: "Lits Jumeaux Rembourrés Enfants",
          slug: "lits-jumeaux-enfants",
          category: "kids_bedrooms",
          categoryNameAr: "غرف نوم الأطفال",
          price: 5200,
          originalPrice: 6500,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/8089165/pexels-photo-8089165.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/8089165/pexels-photo-8089165.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/763146/pexels-photo-763146.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "طقم سريرين للأطفال أو المراهقين بظهر كابيتوني عصري ومريح. حواف مبطنة تحمي الطفل من الصدمات، مع إمكانية إضافة أدراج سفلية لتخزين الألعاب والملابس.",
          woodType: "خشب صلب متين يتحمل حركة الأطفال ونشاطهم",
          fabricType: "أقمشة قطنية ومخملية ناعمة مقاومة للبقع",
          dimensions: "سريران 90 × 190 سم + كومودين وسطي",
          warrantyYears: 5,
          isFeatured: false,
          badge: "طقم سريرين",
        },
        // Dining Chairs
        {
          title: "طقم 6 كراسي مائدة طعام ملكية فاخرة",
          titleFr: "Lot de 6 Chaises de Salle à Manger Prestige",
          slug: "lot-6-chaises-salle-a-manger-prestige",
          category: "dining_chairs",
          categoryNameAr: "كراسي طاولات الطعام",
          price: 2400,
          originalPrice: 3200,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/6758285/pexels-photo-6758285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6758285/pexels-photo-6758285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/6920618/pexels-photo-6920618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "كراسي سفرة مصممة لتجمع بين الراحة التامة عند الجلوس والمظهر الملكي الأنيق. هيكل متين من خشب الزان مع حشوة ميموري فوم ناعمة، وقماش مخمل أو كتان مبطن ومقاوم للسكب والحرارة.",
          woodType: "خشب الزان الصلب مع معالجة ضد الرطوبة والاهتزاز",
          fabricType: "مخمل مقاوم للبقع وسهل المسح ومتاح بعشرات الألوان",
          dimensions: "ارتفاع المقعد: 48 سم | ارتفاع الظهر: 92 سم",
          warrantyYears: 5,
          isFeatured: true,
          badge: "عرض 6 كراسي",
        },
        {
          title: "كراسي سفرة مودرن مخملية بأرجل ذهبية",
          titleFr: "Chaises de Table Velours Pieds Dorés",
          slug: "chaises-table-velours-dore",
          category: "dining_chairs",
          categoryNameAr: "كراسي طاولات الطعام",
          price: 450,
          originalPrice: 600,
          pricePrefix: "للكرسي الواحد",
          imageUrl: "https://images.pexels.com/photos/6920618/pexels-photo-6920618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6920618/pexels-photo-6920618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/7576110/pexels-photo-7576110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "كرسي طاولة طعام عصري بتصميم انسيابي مريح يحتضن الظهر، مع أرجل متينة مطلية بلون ذهبي أو أسود مطفي، تضفي لمسة من الفخامة العصرية على غرفة الطعام.",
          woodType: "هيكل داخلي مقوى مع أرجل معدنية مطلية حرارياً",
          fabricType: "مخمل ملكي ناعم الملمس متوفر بعدة درجات لونية",
          dimensions: "عرض 50 سم × عمق 52 سم × ارتفاع 85 سم",
          warrantyYears: 5,
          isFeatured: false,
          badge: "أحدث صيحة",
        },
        // Accent Chairs & Poufs
        {
          title: "كرسي صالون مفرد فوطاي Nazaré Lounge",
          titleFr: "Fauteuil Nazaré Lounge Velours",
          slug: "fauteuil-nazare-lounge",
          category: "accent_chairs",
          categoryNameAr: "الكراسي الإضافية مع الكنبات",
          price: 1800,
          originalPrice: 2400,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/38750873/pexels-photo-38750873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/38750873/pexels-photo-38750873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/6394545/pexels-photo-6394545.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "كرسي إضافي فخم يوضع بجانب الكنبات أو في زوايا الغرف للقراءة والاسترخاء. مساند مريحة مبطنة وخياطة دقيقة مع وسادة إضافية لدعم الظهر وتناسق تام مع ألوان صالونك.",
          woodType: "قاعدة وأرجل من خشب الزان المغربي الأصيل",
          fabricType: "مخمل مخملي ناعم أو جلد صناعي عالي الجودة",
          dimensions: "عرض 85 سم × عمق 80 سم × ارتفاع 95 سم",
          warrantyYears: 5,
          isFeatured: true,
          badge: "فوطاي فاخر",
        },
        {
          title: "كرسي استرخاء مفرد كلاسيكي كابيتوني",
          titleFr: "Fauteuil Capitonnée Crapaud",
          slug: "fauteuil-capitonnee-crapaud",
          category: "accent_chairs",
          categoryNameAr: "الكراسي الإضافية مع الكنبات",
          price: 1450,
          originalPrice: 1900,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/6394545/pexels-photo-6394545.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6394545/pexels-photo-6394545.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "فوطاي كلاسيكي بتطريز كابيتوني أنيق يكمل أناقة الصالون المغربي أو العصري، مثالي للجلوس واستقبال الضيوف مع راحة استثنائية للظهر.",
          woodType: "خشب صلب منحوت ومصقول بعناية",
          fabricType: "قماش فاخر مقاوم للبقع والأتربة",
          dimensions: "عرض 78 سم × عمق 75 سم × ارتفاع 88 سم",
          warrantyYears: 5,
          isFeatured: false,
          badge: "كلاسيك أنيق",
        },
        {
          title: "بوف جلوس كابيتوني دائري ومستطيل (Pouf)",
          titleFr: "Pouf Rond & Rectangulaire Velours",
          slug: "pouf-rond-rectangulaire-velours",
          category: "accent_chairs",
          categoryNameAr: "الكراسي الإضافية مع الكنبات",
          price: 550,
          originalPrice: 750,
          pricePrefix: "ابتداءً من",
          imageUrl: "https://images.pexels.com/photos/6758246/pexels-photo-6758246.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          galleryUrls: [
            "https://images.pexels.com/photos/6758246/pexels-photo-6758246.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
            "https://images.pexels.com/photos/6758236/pexels-photo-6758236.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          ],
          description: "بوفات عملية وأنيقة متعددة الاستخدامات، تستخدم ككرسي إضافي مريح للضيوف أو كمسند للأقدام أمام الكنبة. خفيفة وسهلة النقل مع صندوق داخلي اختياري لتخزين الأغراض.",
          woodType: "قاعدة خشبية صلبة قادرة على تحمل أوزان عالية",
          fabricType: "قماش بوكلي أو مخمل بألوان مبهجة تناسب الصالون",
          dimensions: "قطر الدائري: 50 سم | المستطيل: 80 × 45 سم",
          warrantyYears: 5,
          isFeatured: false,
          badge: "بوف عملي",
        },
      ]);

      // 3. Reviews
      await db.insert(reviews).values([
        {
          clientName: "كريم المنصوري",
          city: "الدار البيضاء",
          rating: 5,
          comment: "تبارك الله على المعلم جواد وشركة Nazaré Tapisserie، صراحة الصالون طلع أحسن بكتير مما تخيلنا، الإتقان فالتنجيد وخشب الزان صحيح والمواعيد مضبوطة بدقة. الله يوفقكم!",
          productName: "صالون نازاري الملكي الفاخر (L-Shape)",
        },
        {
          clientName: "فاطمة الزهراء بنجلون",
          city: "الرباط - أكدال",
          rating: 5,
          comment: "تعامل في القمة واحترافية عالية. فصلت عندهم غرفة نوم ماستر مع كراسي مائدة الطعام، الجودة ممتازة والأثمنة مناسبة مقارنة بالسوق. شكراً جزيلاً Nazaré Tapisserie.",
          productName: "غرفة نوم ماستر ملكية Nazaré Suite",
        },
        {
          clientName: "حمزة التازي",
          city: "مراكش",
          rating: 5,
          comment: "خدمة توصيل وتركيب ممتازة حتى لمدينة مراكش. درنا غرف نوم الأطفال والكراسي الإضافية، الأولاد عجبهم التصميم بزاف والأمان عالي في كل التفاصيل.",
          productName: "غرفة نوم أطفال متكاملة Nazaré Joy",
        },
        {
          clientName: "سناء العلمي",
          city: "طنجة",
          rating: 5,
          comment: "كراسي طاولة الطعام مع الفوطايات الإضافية زادوا جمالية راقية للبيت ديالي. القماش مضاد للبقع فعلاً وساهل في التنظيف. كنصح أي واحد باغي مفروشات نقية يتعامل معاهم.",
          productName: "طقم 6 كراسي مائدة طعام ملكية فاخرة",
        },
      ]);

      // 4. Sample quote request
      await db.insert(quoteRequests).values({
        clientName: "ياسين بناني",
        clientPhone: "0661223344",
        clientEmail: "yassine.bennani@example.com",
        city: "الدار البيضاء",
        productTitle: "صالون نازاري الملكي الفاخر (L-Shape)",
        message: "أريد صالون زاوية مقاس 3.5 على 2.5 متر باللون البيج الغامق مع قماش مخمل ضد البقع. المرجو الاتصال بي على الواتساب.",
        customDimensions: "3.5m × 2.5m",
        preferredFabric: "Velours Anti-taches Beige",
        status: "new",
      });

      console.log("Database seeded successfully!");
    }
  } catch (err) {
    console.error("Error ensuring DB seeded:", err);
  } finally {
    isSeeding = false;
  }
}
