export interface PresetImage {
  category: string;
  categoryNameAr: string;
  title: string;
  url: string;
}

export const PRESET_IMAGES: PresetImage[] = [
  // Sofas
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "صالون زاوية L-Shape فاخر مع وسائد مريحة",
    url: "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "طقم كنب عصري كلاسيكي بألوان بيج هادئة",
    url: "https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "صالون مخمل ملكي رمادي وبني راقي",
    url: "https://images.pexels.com/photos/8135267/pexels-photo-8135267.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "صالون مفتوح مودرن بإضاءة ساحرة",
    url: "https://images.pexels.com/photos/8135496/pexels-photo-8135496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "كنب مودرن واسع مع سجاد فخم",
    url: "https://images.pexels.com/photos/7174113/pexels-photo-7174113.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    title: "طقم كنب مخمل أخضر زمردي فاخر",
    url: "https://images.pexels.com/photos/30520758/pexels-photo-30520758.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },

  // Bedrooms
  {
    category: "bedrooms",
    categoryNameAr: "غرف النوم",
    title: "غرفة نوم ماستر فندقية مع سرير كابيتوني عريض",
    url: "https://images.pexels.com/photos/39955909/pexels-photo-39955909.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "bedrooms",
    categoryNameAr: "غرف النوم",
    title: "سرير كينغ سايز مبطن مع إضاءة دافئة",
    url: "https://images.pexels.com/photos/7546291/pexels-photo-7546291.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "bedrooms",
    categoryNameAr: "غرف النوم",
    title: "غرفة نوم عصرية بتفاصيل خشبية ودولاب مدمج",
    url: "https://images.pexels.com/photos/38071642/pexels-photo-38071642.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "bedrooms",
    categoryNameAr: "غرف النوم",
    title: "سرير مودرن بأقمشة كتان رمادي مع مرآة تجميل",
    url: "https://images.pexels.com/photos/7546275/pexels-photo-7546275.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "bedrooms",
    categoryNameAr: "غرف النوم",
    title: "غرفة نوم مينيمالست بيضاء ومريحة",
    url: "https://images.pexels.com/photos/7546556/pexels-photo-7546556.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },

  // Kids Bedrooms
  {
    category: "kids_bedrooms",
    categoryNameAr: "غرف نوم الأطفال",
    title: "غرفة نوم أطفال مودرن مع سرير ومكتب مدمج",
    url: "https://images.pexels.com/photos/6670652/pexels-photo-6670652.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "kids_bedrooms",
    categoryNameAr: "غرف نوم الأطفال",
    title: "غرفة أطفال بألوان زاهية وأثاث آمن",
    url: "https://images.pexels.com/photos/7587803/pexels-photo-7587803.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "kids_bedrooms",
    categoryNameAr: "غرف نوم الأطفال",
    title: "سرير أطفال مع خزانة حائط مريحة",
    url: "https://images.pexels.com/photos/7045947/pexels-photo-7045947.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "kids_bedrooms",
    categoryNameAr: "غرف نوم الأطفال",
    title: "سريران توأم مبطنان للأطفال والمراهقين",
    url: "https://images.pexels.com/photos/8089165/pexels-photo-8089165.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },

  // Dining Chairs
  {
    category: "dining_chairs",
    categoryNameAr: "كراسي طاولات الطعام",
    title: "طقم كراسي سفرة مبطنة بقماش فاخر وخشب زان",
    url: "https://images.pexels.com/photos/6758285/pexels-photo-6758285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "dining_chairs",
    categoryNameAr: "كراسي طاولات الطعام",
    title: "كراسي مائدة عصرية مخملية مع طاولة رخامية",
    url: "https://images.pexels.com/photos/6920618/pexels-photo-6920618.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "dining_chairs",
    categoryNameAr: "كراسي طاولات الطعام",
    title: "كراسي سفرة كلاسيكية ناعمة ومريحة",
    url: "https://images.pexels.com/photos/7195594/pexels-photo-7195594.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "dining_chairs",
    categoryNameAr: "كراسي طاولات الطعام",
    title: "طقم كراسي طعام مفتوح مع صالون عصري",
    url: "https://images.pexels.com/photos/7587287/pexels-photo-7587287.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },

  // Accent Chairs & Poufs
  {
    category: "accent_chairs",
    categoryNameAr: "الكراسي الإضافية مع الكنبات",
    title: "كرسي صالون مفرد فوطاي مخمل أحمر ملكي",
    url: "https://images.pexels.com/photos/38750873/pexels-photo-38750873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "accent_chairs",
    categoryNameAr: "الكراسي الإضافية مع الكنبات",
    title: "كرسي استرخاء كابيتوني فخم مع طاولة جانبية ذهبية",
    url: "https://images.pexels.com/photos/6394545/pexels-photo-6394545.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "accent_chairs",
    categoryNameAr: "الكراسي الإضافية مع الكنبات",
    title: "كرسي إضافي ناعم مع وسائد زاهية للصالون",
    url: "https://images.pexels.com/photos/5918518/pexels-photo-5918518.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "accent_chairs",
    categoryNameAr: "الكراسي الإضافية مع الكنبات",
    title: "بوفات جلوس دائرية ومستطيلة كابيتوني عصرية",
    url: "https://images.pexels.com/photos/6758246/pexels-photo-6758246.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    category: "accent_chairs",
    categoryNameAr: "الكراسي الإضافية مع الكنبات",
    title: "بوف صالون متعدد الاستخدامات مع نباتات أنيقة",
    url: "https://images.pexels.com/photos/6758236/pexels-photo-6758236.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
];
