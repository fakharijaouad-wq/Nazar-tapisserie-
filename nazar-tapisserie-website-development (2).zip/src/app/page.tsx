"use client";

import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import CategoriesNav from "@/components/CategoriesNav";
import ProductCard from "@/components/ProductCard";
import ProductModal from "@/components/ProductModal";
import CustomQuoteSection from "@/components/CustomQuoteSection";
import WhyNazare from "@/components/WhyNazare";
import ReviewsSection from "@/components/ReviewsSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import FloatingActions from "@/components/FloatingActions";
import type { Product, Review, SiteSettings } from "@/db/schema";
import { Search, Sparkles, Filter, RefreshCw, Sofa } from "lucide-react";

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const [resProd, resRev, resSet] = await Promise.all([
          fetch("/api/products"),
          fetch("/api/reviews"),
          fetch("/api/settings"),
        ]);

        const prodData = await resProd.json();
        const revData = await resRev.json();
        const setData = await resSet.json();

        if (prodData.success) setProducts(prodData.products);
        if (revData.success) setReviews(revData.reviews);
        if (setData.success) setSettings(setData.settings);
      } catch (err) {
        console.error("Error loading home data:", err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const phone = settings?.phone || "0631363887";
  const email = settings?.email || "fakharijaouad@gmail.com";

  // Filter products by selected category and search
  const filteredProducts = products.filter((prod) => {
    const matchesCategory = activeCategory === "all" || prod.category === activeCategory;
    const matchesSearch =
      searchQuery.trim() === "" ||
      prod.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (prod.titleFr && prod.titleFr.toLowerCase().includes(searchQuery.toLowerCase())) ||
      prod.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 selection:bg-amber-600 selection:text-white">
      {/* 1. Header & Navigation */}
      <Navbar
        phone={phone}
        email={email}
        announcement={settings?.announcement || undefined}
      />

      <main className="flex-1">
        {/* 2. Hero Showcase */}
        <Hero
          phone={phone}
          email={email}
          title={settings?.heroTitle || undefined}
          subtitle={settings?.heroSubtitle || undefined}
        />

        {/* 3. Category Navigation Navigator */}
        <CategoriesNav
          activeCategory={activeCategory}
          onSelectCategory={(cat) => setActiveCategory(cat)}
        />

        {/* 4. Products Catalog Section */}
        <section id="catalog" className="py-16 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-stone-200 pb-6">
            <div className="space-y-2 text-right">
              <span className="text-xs font-bold text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
                كتالوج ورشات Nazaré
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900">
                المفروشات الفاخرة والأثمنة المقترحة
              </h2>
              <p className="text-sm text-stone-600">
                جميع الموديلات قابلة للتفصيل بالمقاس الدقيق، اختيار القماش واللون المناسب لمنزلك
              </p>
            </div>

            {/* Search Input */}
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-stone-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن صالون، سرير، كراسي..."
                className="w-full pr-10 pl-4 py-2.5 text-xs sm:text-sm rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-white shadow-sm"
              />
            </div>
          </div>

          {/* Quick Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {[
              { id: "all", label: "الكل" },
              { id: "sofas", label: "الكنبات والصالونات" },
              { id: "bedrooms", label: "غرف النوم الماستر" },
              { id: "kids_bedrooms", label: "غرف نوم الأطفال" },
              { id: "dining_chairs", label: "كراسي طاولات الطعام" },
              { id: "accent_chairs", label: "الكراسي الإضافية والفوطاي" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
                  activeCategory === tab.id
                    ? "bg-amber-700 text-white shadow-md shadow-amber-900/20"
                    : "bg-white text-stone-700 hover:bg-stone-100 border border-stone-200"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Catalog Grid */}
          {loading ? (
            <div className="py-20 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-amber-600 animate-spin mx-auto" />
              <p className="text-sm font-semibold text-stone-600">جاري تحميل كتالوج المفروشات...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-white rounded-3xl border border-stone-200 p-8">
              <Sofa className="w-12 h-12 text-stone-400 mx-auto" />
              <h3 className="text-base font-bold text-stone-800">لم يتم العثور على منتجات مطابقة للبحث</h3>
              <p className="text-xs text-stone-500">جرب البحث بكلمة أخرى أو اختر قسماً مختلفاً</p>
              <button
                onClick={() => {
                  setActiveCategory("all");
                  setSearchQuery("");
                }}
                className="px-4 py-2 text-xs font-bold bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors"
              >
                عرض كل المفروشات
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  phone={phone}
                  onViewDetails={(p) => setSelectedProduct(p)}
                />
              ))}
            </div>
          )}
        </section>

        {/* 5. Custom Quote & Consultation Section */}
        <CustomQuoteSection phone={phone} />

        {/* 6. Why Nazaré Tapisserie (Quality & Wood Craftsmanship) */}
        <WhyNazare />

        {/* 7. Client Reviews Section */}
        <ReviewsSection initialReviews={reviews} />

        {/* 8. Direct Contact Details */}
        <ContactSection
          phone={phone}
          email={email}
          address={settings?.address || undefined}
          workingHours={settings?.workingHours || undefined}
        />
      </main>

      {/* 9. Footer */}
      <Footer
        phone={phone}
        email={email}
        companyName={settings?.companyName || "Nazaré Tapisserie"}
      />

      {/* 10. Floating Actions (WhatsApp & Call) */}
      <FloatingActions phone={phone} />

      {/* 11. Product Quick View / Order Modal */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          phone={phone}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
