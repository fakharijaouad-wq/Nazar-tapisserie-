"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Sofa,
  Pencil,
  Trash2,
  Plus,
  Image as ImageIcon,
  DollarSign,
  Phone,
  Mail,
  ShieldCheck,
  Check,
  X,
  Search,
  MessageCircle,
  Eye,
  RefreshCw,
  Home,
  Sliders,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Layers,
  Save,
  CheckCircle2,
} from "lucide-react";
import type { Product, QuoteRequest, SiteSettings } from "@/db/schema";
import { PRESET_IMAGES } from "@/lib/preset-images";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<"products" | "quotes" | "settings" | "presets">("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [quotes, setQuotes] = useState<QuoteRequest[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Notification banner
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Edit Product Modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isNewProductModal, setIsNewProductModal] = useState(false);

  // Quick Price / Image Edit Modal
  const [quickEditProduct, setQuickEditProduct] = useState<Product | null>(null);
  const [quickPrice, setQuickPrice] = useState<number>(0);
  const [quickOriginalPrice, setQuickOriginalPrice] = useState<number | "">("");
  const [quickImageUrl, setQuickImageUrl] = useState<string>("");

  // Product Form State (for Full Edit or Add New)
  const [formData, setFormData] = useState({
    title: "",
    titleFr: "",
    category: "sofas",
    categoryNameAr: "الكنبات والصالونات",
    price: 5000,
    originalPrice: 6500,
    pricePrefix: "ابتداءً من",
    imageUrl: "",
    galleryUrls: [] as string[],
    description: "",
    woodType: "خشب الزان الأحمر الرومي الصلب",
    fabricType: "مخمل مقاوم للبقع (Anti-taches)",
    dimensions: "",
    warrantyYears: 5,
    isFeatured: false,
    badge: "",
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [resProd, resQuotes, resSettings] = await Promise.all([
        fetch("/api/products"),
        fetch("/api/quotes"),
        fetch("/api/settings"),
      ]);

      const dataProd = await resProd.json();
      const dataQuotes = await resQuotes.json();
      const dataSettings = await resSettings.json();

      if (dataProd.success) setProducts(dataProd.products);
      if (dataQuotes.success) setQuotes(dataQuotes.quotes);
      if (dataSettings.success) setSettings(dataSettings.settings);
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ في تحميل البيانات");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesCat = selectedCategory === "all" || p.category === selectedCategory;
    const matchesSearch =
      searchQuery === "" ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.titleFr && p.titleFr.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  // Open Quick Edit for Price & Image
  const handleOpenQuickEdit = (p: Product) => {
    setQuickEditProduct(p);
    setQuickPrice(p.price);
    setQuickOriginalPrice(p.originalPrice || "");
    setQuickImageUrl(p.imageUrl);
  };

  // Save Quick Edit (Suggested Price & Image)
  const handleSaveQuickEdit = async () => {
    if (!quickEditProduct) return;
    try {
      const res = await fetch(`/api/products/${quickEditProduct.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          price: quickPrice,
          originalPrice: quickOriginalPrice === "" ? null : quickOriginalPrice,
          imageUrl: quickImageUrl,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setProducts(products.map((item) => (item.id === quickEditProduct.id ? data.product : item)));
        setQuickEditProduct(null);
        showToast("تم تحديث الثمن المقترح والصورة بنجاح! ✨");
      } else {
        showToast("فشل تحديث البيانات");
      }
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء الحفظ");
    }
  };

  // Open Full Edit
  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setIsNewProductModal(false);
    setFormData({
      title: p.title,
      titleFr: p.titleFr || "",
      category: p.category,
      categoryNameAr: p.categoryNameAr,
      price: p.price,
      originalPrice: p.originalPrice || 0,
      pricePrefix: p.pricePrefix || "ابتداءً من",
      imageUrl: p.imageUrl,
      galleryUrls: p.galleryUrls || [p.imageUrl],
      description: p.description,
      woodType: p.woodType || "",
      fabricType: p.fabricType || "",
      dimensions: p.dimensions || "",
      warrantyYears: p.warrantyYears || 5,
      isFeatured: !!p.isFeatured,
      badge: p.badge || "",
    });
  };

  // Open Add New Product
  const handleOpenAddNew = () => {
    setEditingProduct(null);
    setIsNewProductModal(true);
    setFormData({
      title: "",
      titleFr: "",
      category: "sofas",
      categoryNameAr: "الكنبات والصالونات",
      price: 5500,
      originalPrice: 7000,
      pricePrefix: "ابتداءً من",
      imageUrl: PRESET_IMAGES[0].url,
      galleryUrls: [PRESET_IMAGES[0].url],
      description: "تفصيل متقن في ورشات Nazaré Tapisserie مع خشب زان متين وحشوة إسفنج طبي.",
      woodType: "خشب الزان الأحمر الرومي الصلب",
      fabricType: "مخمل مقاوم للبقع (Anti-taches)",
      dimensions: "حسب مقاس الصالون",
      warrantyYears: 5,
      isFeatured: false,
      badge: "جديد",
    });
  };

  // Save Full Product (Create or Update)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const catMap: Record<string, string> = {
        sofas: "الكنبات والصالونات",
        bedrooms: "غرف النوم",
        kids_bedrooms: "غرف نوم الأطفال",
        dining_chairs: "كراسي طاولات الطعام",
        accent_chairs: "الكراسي الإضافية مع الكنبات",
      };

      const payload = {
        ...formData,
        categoryNameAr: catMap[formData.category] || formData.categoryNameAr,
      };

      if (editingProduct) {
        // Update
        const res = await fetch(`/api/products/${editingProduct.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          setProducts(products.map((item) => (item.id === editingProduct.id ? data.product : item)));
          setEditingProduct(null);
          showToast("تم حفظ التعديلات بنجاح!");
        }
      } else {
        // Create new
        const res = await fetch("/api/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          setProducts([data.product, ...products]);
          setIsNewProductModal(false);
          showToast("تمت إضافة المنتج الجديد بنجاح!");
        }
      }
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء حفظ المنتج");
    }
  };

  // Delete product
  const handleDeleteProduct = async (id: number) => {
    if (!confirm("هل أنت متأكد من رغبتك في حذف هذا المنتج من الكتالوج؟")) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setProducts(products.filter((p) => p.id !== id));
        showToast("تم حذف المنتج بنجاح");
      }
    } catch (err) {
      console.error(err);
      showToast("فشل حذف المنتج");
    }
  };

  // Update Quote Status
  const handleUpdateQuoteStatus = async (id: number, status: string) => {
    try {
      const res = await fetch(`/api/quotes/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.success) {
        setQuotes(quotes.map((q) => (q.id === id ? { ...q, status } : q)));
        showToast("تم تحديث حالة الطلب");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Quote
  const handleDeleteQuote = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;
    try {
      const res = await fetch(`/api/quotes/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setQuotes(quotes.filter((q) => q.id !== id));
        showToast("تم حذف الطلب");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        showToast("تم حفظ إعدادات الموقع ومعلومات الاتصال بنجاح!");
      }
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء حفظ الإعدادات");
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 pb-20 font-['Cairo',sans-serif]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-amber-500/50 flex items-center gap-2 text-sm font-bold animate-in fade-in slide-in-from-top duration-300">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Admin Top Navbar */}
      <header className="bg-stone-900 text-white sticky top-0 z-30 shadow-md border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-md">
              <Sofa className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white">Nazaré Tapisserie</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/40 px-2 py-0.5 rounded font-mono">
                  لوحة التحكم
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                إدارة الكتالوج، تعديل الصور، والأثمنة المقترحة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchData}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>

            <Link
              href="/"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs sm:text-sm font-bold transition-all shadow-sm"
            >
              <Home className="w-4 h-4" />
              <span>العودة للموقع</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        {/* Quick Stats Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs text-stone-500 font-semibold block">إجمالي المنتجات</span>
              <span className="text-2xl font-black text-stone-900">{products.length}</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-200">
              <Sofa className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs text-stone-500 font-semibold block">طلبات الزبناء الواردة</span>
              <span className="text-2xl font-black text-emerald-700">{quotes.length}</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
              <MessageCircle className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs text-stone-500 font-semibold block">هاتف الاتصال والواتساب</span>
              <span className="text-sm font-bold font-mono text-stone-900 block" dir="ltr">
                {settings?.phone || "0631363887"}
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs text-stone-500 font-semibold block">البريد الإلكتروني</span>
              <span className="text-xs font-semibold text-stone-700 block truncate max-w-[130px]" dir="ltr">
                {settings?.email || "fakharijaouad@gmail.com"}
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
              <Mail className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 border-b border-stone-200 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab("products")}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === "products"
                ? "bg-amber-600 text-white shadow-md shadow-amber-900/10"
                : "bg-white text-stone-700 hover:bg-stone-50 border border-stone-200"
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>تعديل الأثمنة المقترحة والصور ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("quotes")}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === "quotes"
                ? "bg-amber-600 text-white shadow-md shadow-amber-900/10"
                : "bg-white text-stone-700 hover:bg-stone-50 border border-stone-200"
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>طلبات واستفسارات الزبناء ({quotes.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("presets")}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === "presets"
                ? "bg-amber-600 text-white shadow-md shadow-amber-900/10"
                : "bg-white text-stone-700 hover:bg-stone-50 border border-stone-200"
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>مكتبة الصور الجاهزة للاختيار</span>
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === "settings"
                ? "bg-amber-600 text-white shadow-md shadow-amber-900/10"
                : "bg-white text-stone-700 hover:bg-stone-50 border border-stone-200"
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>إعدادات الاتصال والإعلانات</span>
          </button>
        </div>

        {/* TAB 1: PRODUCTS, PRICES & IMAGES */}
        {activeTab === "products" && (
          <div className="space-y-4">
            {/* Action Bar */}
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              {/* Search & Category Filter */}
              <div className="flex flex-1 flex-col sm:flex-row items-center gap-2.5">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث بالاسم أو الموديل..."
                    className="w-full pr-9 pl-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full sm:w-auto px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                >
                  <option value="all">كل الأقسام</option>
                  <option value="sofas">الكنبات والصالونات</option>
                  <option value="bedrooms">غرف النوم</option>
                  <option value="kids_bedrooms">غرف نوم الأطفال</option>
                  <option value="dining_chairs">كراسي طاولات الطعام</option>
                  <option value="accent_chairs">الكراسي الإضافية وبوف</option>
                </select>
              </div>

              {/* Add New Product Button */}
              <button
                onClick={handleOpenAddNew}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm transition-all shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة منتج وموديل جديد</span>
              </button>
            </div>

            {/* Instruction Banner */}
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  <strong>تعديل سريع:</strong> اضغط على زر{" "}
                  <span className="font-bold underline text-amber-800">&quot;تعديل الثمن والصورة&quot;</span> بجانب
                  أي منتج لتعديل ثمنه وصورته فورياً بضغطة زر دون تعقيد!
                </span>
              </div>
              <span className="text-[11px] text-amber-700 font-mono">
                {filteredProducts.length} عنصر
              </span>
            </div>

            {/* Products Grid / Table */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  {/* Top Image Preview with quick info */}
                  <div className="relative aspect-[16/10] bg-stone-100 overflow-hidden group">
                    <img
                      src={prod.imageUrl}
                      alt={prod.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    <div className="absolute top-2 right-2 flex flex-col gap-1">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-stone-900/80 text-white">
                        {prod.categoryNameAr}
                      </span>
                      {prod.badge && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-600 text-white">
                          {prod.badge}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => handleOpenQuickEdit(prod)}
                      className="absolute bottom-2 left-2 px-2.5 py-1.5 rounded-lg bg-stone-900/90 text-white text-[11px] font-bold flex items-center gap-1.5 hover:bg-amber-600 transition-colors shadow"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                      <span>تغيير الصورة</span>
                    </button>
                  </div>

                  {/* Body Info */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-stone-900 line-clamp-1">{prod.title}</h4>
                      {prod.titleFr && (
                        <p className="text-[11px] text-stone-500 uppercase line-clamp-1">{prod.titleFr}</p>
                      )}

                      {/* Current Suggested Price display */}
                      <div className="mt-3 p-2.5 rounded-xl bg-amber-50/80 border border-amber-200 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-stone-500 block font-medium">
                            الثمن المقترح الحالي:
                          </span>
                          <div className="flex items-baseline gap-1.5">
                            <span className="text-lg font-black text-amber-700">
                              {prod.price.toLocaleString("ar-MA")}
                            </span>
                            <span className="text-xs font-bold text-stone-600">درهم</span>
                            {prod.originalPrice && (
                              <span className="text-[11px] text-stone-400 line-through mr-1">
                                {prod.originalPrice.toLocaleString("ar-MA")} د.م.
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          onClick={() => handleOpenQuickEdit(prod)}
                          className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors"
                        >
                          تعديل الثمن
                        </button>
                      </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => handleOpenQuickEdit(prod)}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Pencil className="w-3 h-3 text-amber-600" />
                        <span>تعديل سريع</span>
                      </button>

                      <button
                        onClick={() => handleOpenEdit(prod)}
                        className="py-1.5 px-3 rounded-lg border border-stone-300 hover:border-amber-500 text-stone-700 text-xs font-semibold transition-colors"
                        title="تعديل كافة التفاصيل"
                      >
                        التفاصيل
                      </button>

                      <button
                        onClick={() => handleDeleteProduct(prod.id)}
                        className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 transition-colors"
                        title="حذف المنتج"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: QUOTES & INQUIRIES */}
        {activeTab === "quotes" && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-stone-900">طلبات عروض الأسعار واستفسارات الزبناء</h3>
                <p className="text-xs text-stone-500">
                  قائمة الزبناء الذين طلبوا تفصيل مفروشات أو استفسروا عبر الموقع
                </p>
              </div>
              <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full">
                {quotes.length} طلب
              </span>
            </div>

            {quotes.length === 0 ? (
              <div className="bg-white p-12 rounded-2xl border border-stone-200 text-center text-stone-500 text-sm">
                لا توجد طلبات جديدة حتى الآن.
              </div>
            ) : (
              <div className="space-y-3">
                {quotes.map((q) => {
                  const cleanPhone = q.clientPhone.replace(/\D/g, "");
                  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;
                  const waClientUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
                    `السلام عليكم ورحمة الله سي ${q.clientName}، معكم ورشات Nazaré Tapisserie بخصوص طلبكم لتفصيل (${q.productTitle || "المفروشات"}).`
                  )}`;

                  return (
                    <div
                      key={q.id}
                      className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 hover:border-amber-300 shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-3">
                          <h4 className="text-base font-bold text-stone-900">{q.clientName}</h4>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              q.status === "completed"
                                ? "bg-emerald-100 text-emerald-800"
                                : q.status === "contacted"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            {q.status === "completed"
                              ? "تم الاتفاق والتنفيذ"
                              : q.status === "contacted"
                              ? "تم التواصل مع الزبون"
                              : "طلب جديد"}
                          </span>
                          {q.city && (
                            <span className="text-xs text-stone-500">📍 {q.city}</span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600">
                          <span className="font-mono font-bold text-stone-900" dir="ltr">
                            📞 {q.clientPhone}
                          </span>
                          {q.productTitle && (
                            <span className="bg-stone-100 px-2 py-0.5 rounded text-stone-800 font-semibold">
                              🛋️ {q.productTitle}
                            </span>
                          )}
                          {q.customDimensions && (
                            <span>📐 مقاس: {q.customDimensions}</span>
                          )}
                          {q.preferredFabric && (
                            <span>🎨 قماش: {q.preferredFabric}</span>
                          )}
                        </div>

                        {q.message && (
                          <p className="text-xs text-stone-600 bg-stone-50 p-2.5 rounded-xl border border-stone-100">
                            &ldquo;{q.message}&rdquo;
                          </p>
                        )}
                      </div>

                      {/* Status changer & WhatsApp button */}
                      <div className="flex items-center gap-2 shrink-0">
                        <a
                          href={waClientUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>واتساب الزبون</span>
                        </a>

                        <a
                          href={`tel:${q.clientPhone}`}
                          className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition-colors"
                          title="اتصال هاتفي"
                        >
                          <Phone className="w-4 h-4 text-amber-600" />
                        </a>

                        <select
                          value={q.status || "new"}
                          onChange={(e) => handleUpdateQuoteStatus(q.id, e.target.value)}
                          className="px-2.5 py-1.5 text-xs rounded-xl border border-stone-300 bg-white"
                        >
                          <option value="new">طلب جديد</option>
                          <option value="contacted">تم التواصل</option>
                          <option value="completed">تم التنفيذ</option>
                          <option value="cancelled">ملغى</option>
                        </select>

                        <button
                          onClick={() => handleDeleteQuote(q.id)}
                          className="p-2 rounded-xl text-rose-600 hover:bg-rose-50 transition-colors"
                          title="حذف الطلب"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: PRESET IMAGE GALLERY (FOR EASY SELECTION) */}
        {activeTab === "presets" && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm space-y-1">
              <h3 className="text-base font-bold text-stone-900">
                مكتبة الصور الفاخرة المعتمدة لـ Nazaré Tapisserie
              </h3>
              <p className="text-xs text-stone-500">
                يمكنك نسخ رابط أي صورة بضغطة زر واحدة واستخدامه فورياً في أي منتج من منتجاتك
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {PRESET_IMAGES.map((preset, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div className="relative aspect-[4/3] bg-stone-100">
                    <img src={preset.url} alt={preset.title} className="w-full h-full object-cover" />
                    <span className="absolute top-1.5 right-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded bg-stone-900/80 text-white">
                      {preset.categoryNameAr}
                    </span>
                  </div>

                  <div className="p-2.5 space-y-2 flex-1 flex flex-col justify-between">
                    <p className="text-[11px] font-semibold text-stone-800 line-clamp-2 leading-snug">
                      {preset.title}
                    </p>

                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(preset.url);
                        showToast("تم نسخ رابط الصورة إلى الحافظة! 📋");
                      }}
                      className="w-full py-1.5 px-2 rounded-lg bg-stone-100 hover:bg-amber-600 hover:text-white text-stone-800 text-[11px] font-bold transition-colors flex items-center justify-center gap-1"
                    >
                      <Check className="w-3 h-3" />
                      <span>نسخ الرابط</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: SETTINGS */}
        {activeTab === "settings" && settings && (
          <div className="max-w-2xl bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-sm space-y-6">
            <div>
              <h3 className="text-lg font-bold text-stone-900">إعدادات الموقع ومعلومات الاتصال</h3>
              <p className="text-xs text-stone-500">
                عدل رقم الهاتف، البريد الإلكتروني، شريط الإعلانات، وأوقات العمل
              </p>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    رقم الهاتف والواتساب *
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.phone || ""}
                    onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                  />
                  <p className="text-[10px] text-stone-400 mt-1">الرقم المعتمد: 0631363887</p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    البريد الإلكتروني للشركة *
                  </label>
                  <input
                    type="email"
                    required
                    value={settings.email || ""}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-stone-400 mt-1">المعتمد: fakharijaouad@gmail.com</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  اسم الشركة التجاري
                </label>
                <input
                  type="text"
                  value={settings.companyName || ""}
                  onChange={(e) => setSettings({ ...settings, companyName: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  شريط الإعلان العلوي (في أعلى الصفحة)
                </label>
                <input
                  type="text"
                  value={settings.announcement || ""}
                  onChange={(e) => setSettings({ ...settings, announcement: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  ساعات وأوقات العمل
                </label>
                <input
                  type="text"
                  value={settings.workingHours || ""}
                  onChange={(e) => setSettings({ ...settings, workingHours: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ التعديلات</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* MODAL 1: QUICK EDIT FOR SUGGESTED PRICE & IMAGE URL */}
      {quickEditProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl relative space-y-5">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900">
                    تعديل الثمن المقترح والصورة
                  </h3>
                  <p className="text-[11px] text-stone-500 truncate max-w-[260px]">
                    {quickEditProduct.title}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setQuickEditProduct(null)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Image Preview & URL */}
            <div className="space-y-3">
              <label className="block text-xs font-bold text-stone-700">
                صورة المنتج ورابطها
              </label>

              <div className="flex items-center gap-3">
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-stone-100 shrink-0 border border-stone-200">
                  <img
                    src={quickImageUrl}
                    alt="معاينة"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=600";
                    }}
                  />
                </div>
                <div className="flex-1 space-y-1">
                  <input
                    type="url"
                    value={quickImageUrl}
                    onChange={(e) => setQuickImageUrl(e.target.value)}
                    placeholder="رابط الصورة (https://...)"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                  />
                  <p className="text-[10px] text-stone-400">
                    يمكنك لصق أي رابط صورة أو اختيار من النماذج أدناه
                  </p>
                </div>
              </div>

              {/* Quick Preset Selector for this product */}
              <div>
                <span className="text-[10px] font-bold text-stone-600 block mb-1.5">
                  أو اختر صورة جاهزة عالية الدقة:
                </span>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {PRESET_IMAGES.slice(0, 7).map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setQuickImageUrl(preset.url)}
                      className={`relative w-12 h-12 rounded-lg overflow-hidden shrink-0 border transition-all ${
                        quickImageUrl === preset.url
                          ? "border-amber-600 ring-2 ring-amber-500/40"
                          : "border-stone-200 opacity-60 hover:opacity-100"
                      }`}
                    >
                      <img src={preset.url} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Price Edit Box */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/70 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-amber-900 mb-1">
                    الثمن المقترح (د.م.) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quickPrice}
                    onChange={(e) => setQuickPrice(parseInt(e.target.value, 10) || 0)}
                    className="w-full px-3 py-2 text-sm font-black text-amber-800 bg-white rounded-xl border border-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الثمن الأصلي قبل التخفيض
                  </label>
                  <input
                    type="number"
                    min="1"
                    placeholder="اختياري (لعرض الخصم)"
                    value={quickOriginalPrice}
                    onChange={(e) =>
                      setQuickOriginalPrice(e.target.value === "" ? "" : parseInt(e.target.value, 10))
                    }
                    className="w-full px-3 py-2 text-sm text-stone-600 bg-white rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Quick % buttons */}
              <div className="flex items-center gap-1.5 pt-1 text-xs">
                <span className="text-[11px] text-stone-500 ml-1">تعديل سريع:</span>
                <button
                  type="button"
                  onClick={() => setQuickPrice(Math.round(quickPrice * 1.1))}
                  className="px-2 py-0.5 rounded bg-white border border-stone-200 text-stone-700 hover:border-amber-500 text-[11px] font-bold"
                >
                  +10%
                </button>
                <button
                  type="button"
                  onClick={() => setQuickPrice(Math.round(quickPrice * 0.9))}
                  className="px-2 py-0.5 rounded bg-white border border-stone-200 text-stone-700 hover:border-amber-500 text-[11px] font-bold"
                >
                  -10%
                </button>
                <button
                  type="button"
                  onClick={() => setQuickPrice(Math.round(quickPrice * 0.8))}
                  className="px-2 py-0.5 rounded bg-white border border-stone-200 text-stone-700 hover:border-amber-500 text-[11px] font-bold"
                >
                  -20%
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setQuickEditProduct(null)}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSaveQuickEdit}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 shadow"
              >
                <Save className="w-3.5 h-3.5" />
                <span>حفظ الثمن والصورة فورياً</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: FULL PRODUCT EDIT OR ADD NEW */}
      {(editingProduct || isNewProductModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-stone-950/75 backdrop-blur-sm overflow-y-auto animate-in fade-in">
          <div className="w-full max-w-2xl bg-white rounded-3xl p-6 sm:p-8 shadow-2xl relative my-auto max-h-[92vh] overflow-y-auto space-y-5">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900">
                {editingProduct ? "تعديل بيانات المنتج والمواصفات" : "إضافة منتج وموديل جديد"}
              </h3>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setIsNewProductModal(false);
                }}
                className="p-1 rounded-full text-stone-400 hover:text-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              {/* Titles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    اسم المنتج بالعربية *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="مثال: صالون نازاري الملكي الزاوية"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الاسم بالفرنسية (اختياري)
                  </label>
                  <input
                    type="text"
                    value={formData.titleFr}
                    onChange={(e) => setFormData({ ...formData, titleFr: e.target.value })}
                    placeholder="Ex: Salon Nazaré Royal"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Category & Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الصنف والقسم *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  >
                    <option value="sofas">الكنبات والصالونات</option>
                    <option value="bedrooms">غرف النوم</option>
                    <option value="kids_bedrooms">غرف نوم الأطفال</option>
                    <option value="dining_chairs">كراسي طاولات الطعام</option>
                    <option value="accent_chairs">الكراسي الإضافية مع الكنبات (فوطاي/بوف)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">شارة خاصة (Badge)</label>
                  <input
                    type="text"
                    value={formData.badge}
                    onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                    placeholder="مثال: الأكثر طلباً، عرض خاص، طقم متكامل..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Prices */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200">
                <div>
                  <label className="block text-xs font-bold text-amber-900 mb-1">
                    الثمن المقترح (د.م.) *
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: parseInt(e.target.value, 10) || 0 })
                    }
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-amber-300 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الثمن قبل التخفيض
                  </label>
                  <input
                    type="number"
                    value={formData.originalPrice || ""}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        originalPrice: e.target.value === "" ? 0 : parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">صيغة الثمن</label>
                  <input
                    type="text"
                    value={formData.pricePrefix}
                    onChange={(e) => setFormData({ ...formData, pricePrefix: e.target.value })}
                    placeholder="ابتداءً من"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Image URL with Preset Picker */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  رابط الصورة الرئيسية *
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    required
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                    placeholder="https://..."
                    className="flex-1 px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                  />
                  {formData.imageUrl && (
                    <div className="w-10 h-10 rounded-lg overflow-hidden bg-stone-100 shrink-0 border border-stone-200">
                      <img src={formData.imageUrl} alt="" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                {/* Quick Presets Picker */}
                <div className="mt-2">
                  <span className="text-[10px] text-stone-500 block mb-1">اختر من النماذج الجاهزة:</span>
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {PRESET_IMAGES.slice(0, 10).map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setFormData({ ...formData, imageUrl: preset.url })}
                        className={`relative w-10 h-10 rounded-lg overflow-hidden shrink-0 border ${
                          formData.imageUrl === preset.url
                            ? "border-amber-600 ring-2 ring-amber-500"
                            : "border-stone-200 opacity-60"
                        }`}
                      >
                        <img src={preset.url} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Specifications */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">نوع الخشب</label>
                  <input
                    type="text"
                    value={formData.woodType}
                    onChange={(e) => setFormData({ ...formData, woodType: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">نوع القماش</label>
                  <input
                    type="text"
                    value={formData.fabricType}
                    onChange={(e) => setFormData({ ...formData, fabricType: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">المقاسات</label>
                  <input
                    type="text"
                    value={formData.dimensions}
                    onChange={(e) => setFormData({ ...formData, dimensions: e.target.value })}
                    placeholder="300 × 240 سم"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الوصف والتفاصيل</label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Featured toggle */}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="featured-check"
                  checked={formData.isFeatured}
                  onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <label htmlFor="featured-check" className="text-xs font-bold text-stone-700 cursor-pointer">
                  عرض كمنتج مميز في الصفحة الرئيسية
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => {
                    setEditingProduct(null);
                    setIsNewProductModal(false);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{editingProduct ? "حفظ التعديلات" : "إضافة المنتج الآن"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
