import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nazaré Tapisserie | صناعة وتنجيد المفروشات المنزلية الراقية والكنبات وغرف النوم",
  description: "شركة Nazaré Tapisserie متخصصة في صناعة وتنجيد الكنبات العصرية، غرف النوم الماستر، غرف أطفال، كراسي طاولات الطعام والكراسي الإضافية مع الكنبات بأعلى جودة. هاتف: 0631363887",
  keywords: "Nazaré Tapisserie, تنجيد صالونات, كنب مغربي, غرف نوم, كراسي طعام, فوطاي, مفروشات المغرب, صناعة أثاث, fakharijaouad@gmail.com",
  openGraph: {
    title: "Nazaré Tapisserie | صالونات ومفروشات فاخرة حسب الطلب",
    description: "ورشات النجارة والتنجيد الرفيع - كنبات، غرف نوم، غرف أطفال، كراسي طعام، فوطايات وبوفات بأجود أنواع خشب الزان والأقمشة المقاومة للبقع.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,600;0,700;1,600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-['Cairo',sans-serif] bg-stone-50 text-stone-900 antialiased selection:bg-amber-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
