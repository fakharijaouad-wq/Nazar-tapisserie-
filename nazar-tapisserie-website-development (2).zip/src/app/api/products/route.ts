import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/init-db";
import { eq, desc, asc, and, like, or } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const featured = searchParams.get("featured");
    const search = searchParams.get("search");

    let query = db.select().from(products);

    const conditions = [];
    if (category && category !== "all") {
      conditions.push(eq(products.category, category));
    }
    if (featured === "true") {
      conditions.push(eq(products.isFeatured, true));
    }
    if (search) {
      conditions.push(
        or(
          like(products.title, `%${search}%`),
          like(products.description, `%${search}%`)
        )
      );
    }

    let results;
    if (conditions.length > 0) {
      results = await query.where(and(...conditions)).orderBy(desc(products.id));
    } else {
      results = await query.orderBy(asc(products.id));
    }

    return NextResponse.json({ success: true, products: results });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch products" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();

    const {
      title,
      titleFr,
      slug,
      category,
      categoryNameAr,
      price,
      originalPrice,
      pricePrefix,
      imageUrl,
      galleryUrls,
      description,
      woodType,
      fabricType,
      dimensions,
      warrantyYears,
      isFeatured,
      badge,
    } = body;

    if (!title || !price || !imageUrl || !category) {
      return NextResponse.json(
        { success: false, error: "العنوان، الفئة، الثمن المقترح، ورابط الصورة حقول مطلوبة" },
        { status: 400 }
      );
    }

    const finalSlug = slug && slug.trim() !== "" 
      ? slug.trim().toLowerCase().replace(/\s+/g, "-") 
      : `item-${Date.now()}`;

    // Map category name in Arabic if not provided
    const catMap: Record<string, string> = {
      sofas: "الكنبات والصالونات",
      bedrooms: "غرف النوم",
      kids_bedrooms: "غرف نوم الأطفال",
      dining_chairs: "كراسي طاولات الطعام",
      accent_chairs: "الكراسي الإضافية مع الكنبات",
    };

    const inserted = await db.insert(products).values({
      title: title.trim(),
      titleFr: titleFr?.trim() || null,
      slug: finalSlug,
      category,
      categoryNameAr: categoryNameAr || catMap[category] || "مفروشات",
      price: parseInt(String(price), 10),
      originalPrice: originalPrice ? parseInt(String(originalPrice), 10) : null,
      pricePrefix: pricePrefix || "ابتداءً من",
      imageUrl: imageUrl.trim(),
      galleryUrls: Array.isArray(galleryUrls) && galleryUrls.length > 0 ? galleryUrls : [imageUrl.trim()],
      description: description || "تفصيل يدوي راقي من ورشات Nazaré Tapisserie",
      woodType: woodType || "خشب الزان الأحمر المتين",
      fabricType: fabricType || "قماش فاخر مقاوم للبقع",
      dimensions: dimensions || "حسب الطلب والمقاس",
      warrantyYears: warrantyYears ? parseInt(String(warrantyYears), 10) : 5,
      isFeatured: !!isFeatured,
      badge: badge?.trim() || null,
    }).returning();

    return NextResponse.json({ success: true, product: inserted[0] }, { status: 201 });
  } catch (error) {
    console.error("POST /api/products error:", error);
    return NextResponse.json({ success: false, error: "Failed to create product" }, { status: 500 });
  }
}
