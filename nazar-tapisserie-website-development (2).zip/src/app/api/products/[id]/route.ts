import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const productId = parseInt(id, 10);
    if (isNaN(productId)) {
      return NextResponse.json({ success: false, error: "معرف غير صالح" }, { status: 400 });
    }

    const item = await db.select().from(products).where(eq(products.id, productId)).limit(1);
    if (item.length === 0) {
      return NextResponse.json({ success: false, error: "المنتج غير موجود" }, { status: 400 });
    }

    return NextResponse.json({ success: true, product: item[0] });
  } catch (error) {
    console.error("GET product error:", error);
    return NextResponse.json({ success: false, error: "خطأ في جلب بيانات المنتج" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const productId = parseInt(id, 10);
    if (isNaN(productId)) {
      return NextResponse.json({ success: false, error: "معرف غير صالح" }, { status: 400 });
    }

    const body = await req.json();

    const updateData: Partial<typeof products.$inferInsert> = {
      updatedAt: new Date(),
    };

    if (body.title !== undefined) updateData.title = body.title.trim();
    if (body.titleFr !== undefined) updateData.titleFr = body.titleFr;
    if (body.category !== undefined) updateData.category = body.category;
    if (body.categoryNameAr !== undefined) updateData.categoryNameAr = body.categoryNameAr;
    if (body.price !== undefined) updateData.price = parseInt(String(body.price), 10);
    if (body.originalPrice !== undefined) {
      updateData.originalPrice = body.originalPrice ? parseInt(String(body.originalPrice), 10) : null;
    }
    if (body.pricePrefix !== undefined) updateData.pricePrefix = body.pricePrefix;
    if (body.imageUrl !== undefined) updateData.imageUrl = body.imageUrl.trim();
    if (body.galleryUrls !== undefined && Array.isArray(body.galleryUrls)) {
      updateData.galleryUrls = body.galleryUrls;
    }
    if (body.description !== undefined) updateData.description = body.description;
    if (body.woodType !== undefined) updateData.woodType = body.woodType;
    if (body.fabricType !== undefined) updateData.fabricType = body.fabricType;
    if (body.dimensions !== undefined) updateData.dimensions = body.dimensions;
    if (body.warrantyYears !== undefined) updateData.warrantyYears = parseInt(String(body.warrantyYears), 10);
    if (body.isFeatured !== undefined) updateData.isFeatured = !!body.isFeatured;
    if (body.badge !== undefined) updateData.badge = body.badge;

    const updated = await db
      .update(products)
      .set(updateData)
      .where(eq(products.id, productId))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "المنتج غير موجود للتعديل" }, { status: 404 });
    }

    return NextResponse.json({ success: true, product: updated[0] });
  } catch (error) {
    console.error("PUT product error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث بيانات المنتج" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const productId = parseInt(id, 10);
    if (isNaN(productId)) {
      return NextResponse.json({ success: false, error: "معرف غير صالح" }, { status: 400 });
    }

    const deleted = await db.delete(products).where(eq(products.id, productId)).returning();

    if (deleted.length === 0) {
      return NextResponse.json({ success: false, error: "المنتج غير موجود للحذف" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "تم حذف المنتج بنجاح" });
  } catch (error) {
    console.error("DELETE product error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف المنتج" }, { status: 500 });
  }
}
