import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/init-db";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDbSeeded();
    const data = await db.select().from(reviews).orderBy(desc(reviews.id));
    return NextResponse.json({ success: true, reviews: data });
  } catch (error) {
    console.error("GET reviews error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الآراء" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const { clientName, city, rating, comment, productName } = body;

    if (!clientName || !city || !comment) {
      return NextResponse.json(
        { success: false, error: "الاسم والمدينة والتعليق حقول مطلوبة" },
        { status: 400 }
      );
    }

    const inserted = await db.insert(reviews).values({
      clientName: clientName.trim(),
      city: city.trim(),
      rating: rating ? parseInt(String(rating), 10) : 5,
      comment: comment.trim(),
      productName: productName?.trim() || null,
    }).returning();

    return NextResponse.json({ success: true, review: inserted[0] }, { status: 201 });
  } catch (error) {
    console.error("POST review error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة الرأي" }, { status: 500 });
  }
}
