import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quoteRequests } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/init-db";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDbSeeded();
    const quotes = await db.select().from(quoteRequests).orderBy(desc(quoteRequests.id));
    return NextResponse.json({ success: true, quotes });
  } catch (error) {
    console.error("GET quotes error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب طلبات عروض الأسعار" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();

    const {
      clientName,
      clientPhone,
      clientEmail,
      city,
      productId,
      productTitle,
      message,
      customDimensions,
      preferredFabric,
    } = body;

    if (!clientName || !clientPhone) {
      return NextResponse.json(
        { success: false, error: "الاسم ورقم الهاتف حقول إجبارية للتواصل" },
        { status: 400 }
      );
    }

    const inserted = await db.insert(quoteRequests).values({
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      clientEmail: clientEmail?.trim() || null,
      city: city?.trim() || null,
      productId: productId ? parseInt(String(productId), 10) : null,
      productTitle: productTitle?.trim() || null,
      message: message?.trim() || null,
      customDimensions: customDimensions?.trim() || null,
      preferredFabric: preferredFabric?.trim() || null,
      status: "new",
    }).returning();

    return NextResponse.json({
      success: true,
      quote: inserted[0],
      message: "تم إرسال طلبكم بنجاح! سيتواصل معكم فريق Nazaré Tapisserie في أقرب وقت.",
    }, { status: 201 });
  } catch (error) {
    console.error("POST quote error:", error);
    return NextResponse.json({ success: false, error: "فشل إرسال الطلب، يرجى المحاولة ثانية" }, { status: 500 });
  }
}
