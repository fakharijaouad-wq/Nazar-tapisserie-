import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quoteRequests } from "@/db/schema";
import { eq } from "drizzle-orm";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const quoteId = parseInt(id, 10);
    if (isNaN(quoteId)) {
      return NextResponse.json({ success: false, error: "معرف غير صالح" }, { status: 400 });
    }

    const body = await req.json();
    const { status } = body;

    const updated = await db
      .update(quoteRequests)
      .set({ status })
      .where(eq(quoteRequests.id, quoteId))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ success: false, error: "الطلب غير موجود" }, { status: 404 });
    }

    return NextResponse.json({ success: true, quote: updated[0] });
  } catch (error) {
    console.error("PATCH quote error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث حالة الطلب" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params;
    const quoteId = parseInt(id, 10);
    if (isNaN(quoteId)) {
      return NextResponse.json({ success: false, error: "معرف غير صالح" }, { status: 400 });
    }

    const deleted = await db
      .delete(quoteRequests)
      .where(eq(quoteRequests.id, quoteId))
      .returning();

    if (deleted.length === 0) {
      return NextResponse.json({ success: false, error: "الطلب غير موجود" }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: "تم حذف الطلب بنجاح" });
  } catch (error) {
    console.error("DELETE quote error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف الطلب" }, { status: 500 });
  }
}
