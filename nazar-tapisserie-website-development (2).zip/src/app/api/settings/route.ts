import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { ensureDbSeeded } from "@/lib/init-db";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDbSeeded();
    const settingsList = await db.select().from(siteSettings).limit(1);
    if (settingsList.length === 0) {
      return NextResponse.json({
        success: true,
        settings: {
          companyName: "Nazaré Tapisserie",
          phone: "0631363887",
          email: "fakharijaouad@gmail.com",
          address: "المغرب - ورشات الصنعة الرفيعة والتوصيل والتركيب لجميع المدن",
          announcement: "✨ تفصيل حسب المقاس والطلب مع ضمان 5 سنوات وتوصيل وتركيب مجاني في جميع أنحاء المغرب ✨",
          workingHours: "طيلة أيام الأسبوع من 9:00 صباحاً حتى 20:30 مساءً",
          heroTitle: "صناعة وتنجيد المفروشات المنزلية الفاخرة والكنبات وغرف النوم",
          heroSubtitle: "شركة Nazaré Tapisserie متخصصة في صناعة وتنجيد الكنبات العصرية، غرف النوم الماستر، غرف نوم الأطفال، كراسي طاولات الطعام وكراسي الصالونات بأجود أنواع خشب الزان وأرقى الأقمشة الإيطالية والتركية.",
        },
      });
    }
    return NextResponse.json({ success: true, settings: settingsList[0] });
  } catch (error) {
    console.error("GET settings error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب إعدادات الموقع" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    await ensureDbSeeded();
    const body = await req.json();

    const existing = await db.select().from(siteSettings).limit(1);
    if (existing.length === 0) {
      const inserted = await db.insert(siteSettings).values({
        companyName: body.companyName || "Nazaré Tapisserie",
        phone: body.phone || "0631363887",
        email: body.email || "fakharijaouad@gmail.com",
        address: body.address || "المغرب - ورشات الصنعة الرفيعة",
        announcement: body.announcement || "",
        workingHours: body.workingHours || "يومياً من 9:00 ص إلى 20:30 م",
        heroTitle: body.heroTitle,
        heroSubtitle: body.heroSubtitle,
      }).returning();
      return NextResponse.json({ success: true, settings: inserted[0] });
    }

    const updated = await db
      .update(siteSettings)
      .set({
        companyName: body.companyName,
        phone: body.phone,
        email: body.email,
        address: body.address,
        announcement: body.announcement,
        workingHours: body.workingHours,
        heroTitle: body.heroTitle,
        heroSubtitle: body.heroSubtitle,
        updatedAt: new Date(),
      })
      .where(eq(siteSettings.id, existing[0].id))
      .returning();

    return NextResponse.json({ success: true, settings: updated[0] });
  } catch (error) {
    console.error("PUT settings error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث إعدادات الموقع" }, { status: 500 });
  }
}
