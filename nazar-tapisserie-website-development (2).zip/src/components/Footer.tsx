import Link from "next/link";
import { Sofa, Phone, Mail, ShieldCheck, Heart } from "lucide-react";

interface FooterProps {
  phone?: string;
  email?: string;
  companyName?: string;
}

export default function Footer({
  phone = "0631363887",
  email = "fakharijaouad@gmail.com",
  companyName = "Nazaré Tapisserie",
}: FooterProps) {
  return (
    <footer className="bg-stone-950 text-stone-300 border-t border-stone-800 pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-600 to-amber-800 flex items-center justify-center text-white">
                <Sofa className="w-5 h-5 text-amber-100" />
              </div>
              <div>
                <span className="font-['Playfair_Display'] font-bold text-xl text-white block">
                  {companyName}
                </span>
                <span className="text-[11px] text-amber-400 font-medium">
                  صناعة وتنجيد المفروشات المنزلية الراقية
                </span>
              </div>
            </div>

            <p className="text-xs text-stone-400 leading-relaxed">
              متخصصون في صناعة الكنبات والصالونات العصرية، غرف النوم الماستر، غرف نوم الأطفال، كراسي طاولات الطعام والكراسي الإضافية مع الكنبات بأعلى جودة خشب الزان وأرقى أقمشة التنجيد.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-stone-800 pb-2">
              أقسام المفروشات
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <Link href="/#categories" className="hover:text-amber-400 transition-colors">
                  🛋️ الكنبات والصالونات العصرية
                </Link>
              </li>
              <li>
                <Link href="/#categories" className="hover:text-amber-400 transition-colors">
                  🛏️ غرف النوم الماستر الملكية
                </Link>
              </li>
              <li>
                <Link href="/#categories" className="hover:text-amber-400 transition-colors">
                  🧸 غرف نوم الأطفال الآمنة
                </Link>
              </li>
              <li>
                <Link href="/#categories" className="hover:text-amber-400 transition-colors">
                  🪑 كراسي طاولات الطعام الفاخرة
                </Link>
              </li>
              <li>
                <Link href="/#categories" className="hover:text-amber-400 transition-colors">
                  💺 الكراسي الإضافية، الفوطايات والبوفات
                </Link>
              </li>
            </ul>
          </div>

          {/* Guarantees & Workshop */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-stone-800 pb-2">
              خدماتنا وضماناتنا
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>✓ تفصيل مخصص بالمقاس 100%</li>
              <li>✓ خشب الزان الأحمر الرومي الصلب</li>
              <li>✓ إسفنج طبي عالي الكثافة (D30/D33)</li>
              <li>✓ أقمشة مخملية وكتان ضد البقع</li>
              <li>✓ شهادة ضمان 5 سنوات معتمدة</li>
              <li>✓ توصيل وتركيب لكافة مدن المغرب</li>
            </ul>
          </div>

          {/* Direct Contact */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-stone-800 pb-2">
              معلومات الاتصال المباشر
            </h4>
            <div className="space-y-2.5 text-xs text-stone-300">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-mono" dir="ltr">{phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span dir="ltr">{email}</span>
              </div>
              <div className="pt-2">
                <Link
                  href="/admin"
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-700 text-stone-300 hover:text-amber-400 hover:border-amber-400 transition-colors text-xs font-semibold"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                  <span>لوحة تحكم الإدارة (الصور والأسعار)</span>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Credits */}
        <div className="pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-500 text-center sm:text-right">
          <div>
            جميع الحقوق محفوظة © {new Date().getFullYear()} {companyName} — تصنيع وتنجيد المفروشات المنزلية الراقية.
          </div>
          <div className="flex items-center gap-1">
            <span>صنع بإتقان وشغف في المغرب</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500 inline" />
          </div>
        </div>
      </div>
    </footer>
  );
}
