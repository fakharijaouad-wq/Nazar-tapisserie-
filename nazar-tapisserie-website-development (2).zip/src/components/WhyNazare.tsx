import { ShieldCheck, Award, Ruler, Truck, Sparkles, Check, Layers, Scissors, HeartHandshake } from "lucide-react";

export default function WhyNazare() {
  const steps = [
    {
      num: "01",
      title: "اختيار التصميم والمقاس",
      desc: "تختار الموديل من كتالوجنا أو ترسل صورة الموديل الذي ترغب بتفصيله، ونحدد المقاسات بدقة.",
      icon: Ruler,
    },
    {
      num: "02",
      title: "انتقاء الخشب وقماش التنجيد",
      desc: "نوفر لك عينات أقمشة مخملية أو كتان ضد البقع، مع هياكل خشب الزان الأحمر المصمت.",
      icon: Scissors,
    },
    {
      num: "03",
      title: "التصنيع والحرفية اليدوية",
      desc: "يقوم حرفيو Nazaré Tapisserie بالنجارة والتنجيد وخياطة الكابيتوني بدقة متناهية وإسفنج طبي D30/D33.",
      icon: Layers,
    },
    {
      num: "04",
      title: "التوصيل والتركيب والضمان",
      desc: "توصيل آمن لغاية منزلك، تركيب محترف وفحص كامل مع شهادة ضمان 5 سنوات.",
      icon: Truck,
    },
  ];

  const features = [
    {
      title: "خشب الزان الأحمر الصلب (Hêtre Rouge)",
      desc: "لا نستخدم الخشب الهش، بل نعتمد على خشب الزان المستورد المعالج ضد الحشرات والرطوبة لعمر افتراضي يدوم عقوداً.",
      icon: Award,
    },
    {
      title: "إسفنج طبي عالي الكثافة (Mousse D30/D33)",
      desc: "حشوات إسفنجية طبية مريحة تحافظ على قوامها ولا تهبط مع الاستخدام اليومي المكثف.",
      icon: Layers,
    },
    {
      title: "أقمشة مقاومة للبقع والسوائل (Anti-taches)",
      desc: "تشكيلة أقمشة إيطالية وتركية ومغربية سهلة المسح والتنظيف، ومقاومة للتمزق والبهتان.",
      icon: Sparkles,
    },
    {
      title: "ضمان 5 سنوات وخدمة ما بعد البيع",
      desc: "نقف وراء جودة صناعتنا بضمان حقيقي يشمل الهيكل الخشبي وحشوات التنجيد.",
      icon: ShieldCheck,
    },
  ];

  return (
    <section id="craftsmanship" className="py-16 sm:py-24 bg-stone-50 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="text-xs font-bold text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
            سر جودة Nazaré Tapisserie
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-stone-900">
            صنعة مغربية متوارثة بمعايير عصرية عالمية
          </h2>
          <p className="text-sm sm:text-base text-stone-600">
            نجمع في ورشاتنا بين مهارة النجار والمُنَجِّد الماهر لتقديم مفروشات تدوم في بيتك وتزيد من جماليته
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 border border-stone-200 hover:border-amber-400 hover:shadow-lg transition-all space-y-3"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-200">
                <item.icon className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900">{item.title}</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Process Steps */}
        <div className="bg-stone-900 text-white rounded-3xl p-6 sm:p-10 relative overflow-hidden">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <span className="text-xs font-bold text-amber-400">مراحل التنفيذ</span>
            <h3 className="text-xl sm:text-2xl font-bold">كيف نقوم بتفصيل مفروشاتك من البداية للتسليم؟</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, idx) => (
              <div key={idx} className="relative space-y-3 p-4 rounded-2xl bg-stone-800/60 border border-stone-700">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-amber-400 font-mono">{step.num}</span>
                  <div className="w-8 h-8 rounded-lg bg-stone-700 flex items-center justify-center text-amber-300">
                    <step.icon className="w-4 h-4" />
                  </div>
                </div>
                <h4 className="text-sm font-bold text-stone-100">{step.title}</h4>
                <p className="text-xs text-stone-300 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
