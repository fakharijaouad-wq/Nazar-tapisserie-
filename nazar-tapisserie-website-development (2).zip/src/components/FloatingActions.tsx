"use client";

import { MessageCircle, Phone } from "lucide-react";

interface FloatingActionsProps {
  phone?: string;
}

export default function FloatingActions({ phone = "0631363887" }: FloatingActionsProps) {
  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    "السلام عليكم ورحمة الله، أتواصل معكم عبر موقع Nazaré Tapisserie للاستفسار عن تفصيل مفروشات."
  )}`;

  return (
    <div className="fixed bottom-5 left-5 z-40 flex flex-col items-center gap-3">
      {/* WhatsApp Floating Button */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="تواصل عبر الواتساب"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-xl shadow-emerald-950/30 hover:scale-110 transition-all duration-300"
      >
        <MessageCircle className="w-7 h-7" />
        <span className="absolute left-16 bg-stone-900 text-white text-xs font-bold px-3 py-1.5 rounded-xl whitespace-nowrap shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none hidden sm:block">
          تواصل معنا واتساب: {phone}
        </span>
      </a>

      {/* Direct Call Floating Button */}
      <a
        href={`tel:${phone}`}
        aria-label="اتصال هاتف"
        className="group relative flex items-center justify-center w-12 h-12 rounded-full bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-950/30 hover:scale-110 transition-all duration-300"
      >
        <Phone className="w-5 h-5" />
        <span className="absolute left-16 bg-stone-900 text-white text-xs font-bold px-3 py-1.5 rounded-xl whitespace-nowrap shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none hidden sm:block">
          اتصال مباشر: {phone}
        </span>
      </a>
    </div>
  );
}
