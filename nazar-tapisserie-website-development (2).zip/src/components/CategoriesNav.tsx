"use client";

import { Sofa, Bed, Baby, UtensilsCrossed, Armchair } from "lucide-react";

interface CategoriesNavProps {
  activeCategory: string;
  onSelectCategory: (category: string) => void;
}

export const CATEGORIES_DATA = [
  {
    id: "all",
    nameAr: "جميع المفروشات",
    subtitle: "كتالوج كامل متكامل",
    icon: Sofa,
    bgImage: "https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
  {
    id: "sofas",
    nameAr: "الكنبات والصالونات",
    subtitle: "صالونات زاوية L، كنب عصري ومغربي",
    icon: Sofa,
    bgImage: "https://images.pexels.com/photos/6758245/pexels-photo-6758245.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
  {
    id: "bedrooms",
    nameAr: "غرف النوم",
    subtitle: "أسرّة كابيتوني ماستر وغرف كاملة",
    icon: Bed,
    bgImage: "https://images.pexels.com/photos/39955909/pexels-photo-39955909.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
  {
    id: "kids_bedrooms",
    nameAr: "غرف نوم الأطفال",
    subtitle: "أسرّة آمنة، مبهجة وعصرية",
    icon: Baby,
    bgImage: "https://images.pexels.com/photos/6670652/pexels-photo-6670652.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
  {
    id: "dining_chairs",
    nameAr: "كراسي طاولات الطعام",
    subtitle: "أطقم كراسي مائدة سفرة فاخرة",
    icon: UtensilsCrossed,
    bgImage: "https://images.pexels.com/photos/6758285/pexels-photo-6758285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
  {
    id: "accent_chairs",
    nameAr: "الكراسي الإضافية مع الكنبات",
    subtitle: "فوطايات مودرن، كراسي جانبية وبوفات",
    icon: Armchair,
    bgImage: "https://images.pexels.com/photos/38750873/pexels-photo-38750873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400",
  },
];

export default function CategoriesNav({ activeCategory, onSelectCategory }: CategoriesNavProps) {
  return (
    <section id="categories" className="py-12 bg-stone-100 border-y border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-8 space-y-2">
          <span className="text-xs font-bold text-amber-700 uppercase tracking-widest bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
            تخصصات ورشات Nazaré Tapisserie
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900">
            اختر صنف المفروشات الذي تبحث عنه
          </h2>
          <p className="text-sm text-stone-600">
            نقدم لكم تشكيلة واسعة تم تفصيلها بأجود أخشاب الزان والأقمشة مع إمكانية تعديل المقاس والألوان حسب رغبتكم
          </p>
        </div>

        {/* Category Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {CATEGORIES_DATA.map((cat) => {
            const IconComponent = cat.icon;
            const isActive = activeCategory === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => {
                  onSelectCategory(cat.id);
                  // smooth scroll down to catalog if needed
                  const catalogEl = document.getElementById("catalog");
                  if (catalogEl) {
                    catalogEl.scrollIntoView({ behavior: "smooth" });
                  }
                }}
                className={`group relative rounded-2xl overflow-hidden p-3.5 sm:p-4 text-right transition-all flex flex-col justify-between h-36 sm:h-44 border ${
                  isActive
                    ? "border-amber-600 ring-2 ring-amber-600/50 shadow-lg scale-102 bg-stone-900 text-white"
                    : "border-stone-200 bg-white hover:border-amber-400 hover:shadow-md text-stone-800"
                }`}
              >
                {/* Background image preview with overlay */}
                <div className="absolute inset-0 z-0 overflow-hidden opacity-20 group-hover:opacity-30 transition-opacity">
                  <img
                    src={cat.bgImage}
                    alt={cat.nameAr}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div
                    className={`absolute inset-0 ${
                      isActive ? "bg-stone-950/80" : "bg-stone-900/60"
                    }`}
                  />
                </div>

                {/* Top Icon */}
                <div className="relative z-10">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                      isActive
                        ? "bg-amber-600 text-white"
                        : "bg-amber-50 text-amber-700 border border-amber-200 group-hover:bg-amber-600 group-hover:text-white"
                    }`}
                  >
                    <IconComponent className="w-5 h-5" />
                  </div>
                </div>

                {/* Bottom text */}
                <div className="relative z-10 pt-2">
                  <h3
                    className={`text-xs sm:text-sm font-bold line-clamp-2 leading-snug ${
                      isActive ? "text-amber-300" : "text-stone-900 group-hover:text-amber-700"
                    }`}
                  >
                    {cat.nameAr}
                  </h3>
                  <p
                    className={`text-[10px] mt-1 line-clamp-1 ${
                      isActive ? "text-stone-300" : "text-stone-500"
                    }`}
                  >
                    {cat.subtitle}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
