"use client";

import { MessageCircle, Eye, ShieldCheck, Tag, Ruler } from "lucide-react";
import type { Product } from "@/db/schema";

interface ProductCardProps {
  product: Product;
  phone?: string;
  onViewDetails: (product: Product) => void;
}

export default function ProductCard({
  product,
  phone = "0631363887",
  onViewDetails,
}: ProductCardProps) {
  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;

  const waMessage = `السلام عليكم ورحمة الله، أنا مهتم بـ "${product.title}" المقترح بثمن (${product.price} درهم) لدى Nazaré Tapisserie. أود الاستفسار عن تفاصيل المقاسات واختيار القماش والتوصيل.`;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(waMessage)}`;

  // Calculate discount percentage if original price exists
  const discountPercent =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-stone-200 hover:border-amber-400 hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
      {/* Image container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-100">
        <img
          src={product.imageUrl}
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
        />

        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
          <button
            onClick={() => onViewDetails(product)}
            className="w-full py-2 bg-white/95 text-stone-900 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md hover:bg-amber-600 hover:text-white transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>عرض كافة التفاصيل والصور</span>
          </button>
        </div>

        {/* Badges on top */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
          {product.badge && (
            <span className="bg-amber-600 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg shadow-sm">
              {product.badge}
            </span>
          )}
          {discountPercent && (
            <span className="bg-rose-600 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-lg shadow-sm w-fit">
              تخفيض {discountPercent}%
            </span>
          )}
        </div>

        {/* Category tag on top left */}
        <div className="absolute top-3 left-3 z-10">
          <span className="bg-stone-900/80 backdrop-blur-sm text-stone-200 text-[10px] font-medium px-2.5 py-1 rounded-lg border border-stone-700">
            {product.categoryNameAr}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* French subtitle if exists */}
          {product.titleFr && (
            <div className="text-[11px] text-amber-700 font-semibold tracking-wide uppercase line-clamp-1 mb-1">
              {product.titleFr}
            </div>
          )}

          {/* Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="text-base sm:text-lg font-bold text-stone-900 group-hover:text-amber-800 transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {product.title}
          </h3>

          {/* Brief specs pills */}
          <div className="mt-2.5 space-y-1.5 text-xs text-stone-600">
            {product.woodType && (
              <div className="flex items-center gap-1.5 text-stone-600 line-clamp-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600 shrink-0" />
                <span className="font-semibold text-stone-700">الخشب:</span>
                <span className="text-stone-600 truncate">{product.woodType}</span>
              </div>
            )}
            {product.fabricType && (
              <div className="flex items-center gap-1.5 text-stone-600 line-clamp-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-600 shrink-0" />
                <span className="font-semibold text-stone-700">القماش:</span>
                <span className="text-stone-600 truncate">{product.fabricType}</span>
              </div>
            )}
          </div>
        </div>

        {/* Price & Guarantee Box */}
        <div className="pt-3 border-t border-stone-100 flex items-end justify-between">
          <div>
            <span className="text-[11px] text-stone-500 block">
              {product.pricePrefix || "الثمن المقترح"}
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl sm:text-2xl font-black text-amber-700">
                {product.price.toLocaleString("ar-MA")}
                <span className="text-xs font-bold text-stone-600 mr-1">د.م.</span>
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-xs text-stone-400 line-through">
                  {product.originalPrice.toLocaleString("ar-MA")} د.م.
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200 shrink-0">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ضمان {product.warrantyYears || 5} سنوات</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => onViewDetails(product)}
            className="w-full py-2.5 px-3 rounded-xl border border-stone-300 hover:border-amber-600 hover:bg-amber-50 text-stone-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Eye className="w-3.5 h-3.5 text-amber-700" />
            <span>معاينة وتفاصيل</span>
          </button>

          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>طلب بالواتساب</span>
          </a>
        </div>
      </div>
    </div>
  );
}
