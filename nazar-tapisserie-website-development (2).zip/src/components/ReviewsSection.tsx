"use client";

import { useState } from "react";
import { Star, MessageSquarePlus, CheckCircle2, User, MapPin } from "lucide-react";
import type { Review } from "@/db/schema";

interface ReviewsSectionProps {
  initialReviews?: Review[];
}

export default function ReviewsSection({ initialReviews = [] }: ReviewsSectionProps) {
  const [reviewsList, setReviewsList] = useState<Review[]>(initialReviews);
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState("");
  const [city, setCity] = useState("الدار البيضاء");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [productName, setProductName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !comment) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: name,
          city,
          rating,
          comment,
          productName,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setReviewsList([data.review, ...reviewsList]);
        setSuccess(true);
        setTimeout(() => {
          setShowAddModal(false);
          setSuccess(false);
          setName("");
          setComment("");
        }, 1800);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="reviews" className="py-16 sm:py-24 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 text-right">
          <div>
            <span className="text-xs font-bold text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
              ثقة عملائنا فخرنا
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 mt-2">
              تجارب وآراء عملائنا الكرام
            </h2>
            <p className="text-sm text-stone-600 mt-1">
              نفخر برضا زبنائنا في مختلف المدن المغربية ونسعى دوماً للأفضل
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-amber-600 text-amber-700 hover:bg-amber-600 hover:text-white font-bold text-xs sm:text-sm transition-colors w-fit"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>شاركنا تجربتك ورأيك</span>
          </button>
        </div>

        {/* Reviews Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {reviewsList.map((rev) => (
            <div
              key={rev.id}
              className="p-5 rounded-2xl bg-stone-50 border border-stone-200/80 hover:border-amber-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Stars */}
                <div className="flex items-center gap-1 text-amber-500">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < (rev.rating || 5) ? "fill-amber-400 text-amber-400" : "text-stone-300"
                      }`}
                    />
                  ))}
                </div>

                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed italic">
                  &ldquo;{rev.comment}&rdquo;
                </p>
              </div>

              <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-stone-900">{rev.clientName}</h4>
                  <div className="flex items-center gap-1 text-[11px] text-stone-500">
                    <MapPin className="w-3 h-3 text-amber-600" />
                    <span>{rev.city}</span>
                  </div>
                </div>

                {rev.productName && (
                  <span className="text-[10px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 max-w-[120px] truncate">
                    {rev.productName}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal for adding review */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl relative">
            <h3 className="text-lg font-bold text-stone-900 mb-4">أضف تقييمك ورأيك في Nazaré Tapisserie</h3>

            {success ? (
              <div className="p-4 rounded-xl bg-emerald-50 text-emerald-800 text-sm font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>شكراً جزيلاً! تم نشر رأيك بنجاح.</span>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">الاسم الكامل *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="اسمك الكريم"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">المدينة *</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="الدار البيضاء، الرباط..."
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">التقييم (من 5)</label>
                    <select
                      value={rating}
                      onChange={(e) => setRating(parseInt(e.target.value, 10))}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      <option value="5">⭐⭐⭐⭐⭐ 5 نجوم</option>
                      <option value="4">⭐⭐⭐⭐ 4 نجوم</option>
                      <option value="3">⭐⭐⭐ 3 نجوم</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">اسم المنتج المفصل (اختياري)</label>
                  <input
                    type="text"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    placeholder="مثال: صالون زاوية، غرفة نوم، كراسي طعام..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">رأيك وتجربتك *</label>
                  <textarea
                    rows={3}
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="شاركنا رأيك في جودة الخشب، الأقمشة، التوصيل والمواعيد..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-4 py-2 text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-xl disabled:opacity-50"
                  >
                    {submitting ? "جاري الإرسال..." : "إرسال التقييم"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
