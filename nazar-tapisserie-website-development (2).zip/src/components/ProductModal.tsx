"use client";

import { useState } from "react";
import { X, MessageCircle, Phone, ShieldCheck, Check, Ruler, Award, Sparkles, Send } from "lucide-react";
import type { Product } from "@/db/schema";

interface ProductModalProps {
  product: Product | null;
  phone?: string;
  onClose: () => void;
}

export default function ProductModal({ product, phone = "0631363887", onClose }: ProductModalProps) {
  if (!product) return null;

  const [activeImage, setActiveImage] = useState<string>(product.imageUrl);
  const [formName, setFormName] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formCity, setFormCity] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const gallery = product.galleryUrls && product.galleryUrls.length > 0 
    ? product.galleryUrls 
    : [product.imageUrl];

  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;

  const waMessage = `السلام عليكم ورحمة الله، أنا مهتم بـ "${product.title}" المقترح بثمن (${product.price} درهم) لدى Nazaré Tapisserie. أود الاستفسار والتنسيق لطلب التفصيل.`;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(waMessage)}`;

  const handleSubmitQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) return;

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: formName,
          clientPhone: formPhone,
          city: formCity,
          productId: product.id,
          productTitle: product.title,
          message: formNotes,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSubmitSuccess(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-stone-950/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header with Close */}
        <div className="flex items-center justify-between p-4 sm:px-6 border-b border-stone-200 bg-stone-50 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-lg">
              {product.categoryNameAr}
            </span>
            {product.badge && (
              <span className="text-xs font-bold text-white bg-amber-600 px-2.5 py-1 rounded-lg">
                {product.badge}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6 flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Gallery Section */}
            <div className="lg:col-span-6 space-y-3">
              <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-stone-100 border border-stone-200">
                <img
                  src={activeImage}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Thumbnails */}
              {gallery.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {gallery.map((imgUrl, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImage(imgUrl)}
                      className={`relative w-16 h-16 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                        activeImage === imgUrl
                          ? "border-amber-600 ring-2 ring-amber-500/40"
                          : "border-stone-200 opacity-70 hover:opacity-100"
                      }`}
                    >
                      <img src={imgUrl} alt="صورة إضافية" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Quality Highlights */}
              <div className="grid grid-cols-2 gap-2 text-xs text-stone-700 pt-2">
                <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200/60 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>ضمان {product.warrantyYears || 5} سنوات</span>
                </div>
                <div className="p-2.5 rounded-xl bg-stone-100 border border-stone-200 flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>خشب زان أحمر أصيل</span>
                </div>
              </div>
            </div>

            {/* Information & Order Section */}
            <div className="lg:col-span-6 space-y-5 flex flex-col justify-between">
              <div>
                {product.titleFr && (
                  <p className="text-xs font-bold text-amber-700 uppercase tracking-wider mb-1">
                    {product.titleFr}
                  </p>
                )}
                <h2 className="text-xl sm:text-2xl font-black text-stone-900 leading-snug">
                  {product.title}
                </h2>

                {/* Suggested Price display */}
                <div className="mt-3 p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-stone-600 block font-medium">
                      {product.pricePrefix || "الثمن المقترح"}
                    </span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl sm:text-3xl font-black text-amber-800">
                        {product.price.toLocaleString("ar-MA")}{" "}
                        <span className="text-sm font-bold text-stone-700">درهم</span>
                      </span>
                      {product.originalPrice && product.originalPrice > product.price && (
                        <span className="text-sm text-stone-400 line-through">
                          {product.originalPrice.toLocaleString("ar-MA")} د.م.
                        </span>
                      )}
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-lg">
                    تفصيل حسب مقاسك
                  </span>
                </div>

                {/* Description */}
                <p className="mt-4 text-sm text-stone-600 leading-relaxed">
                  {product.description}
                </p>

                {/* Specs list */}
                <div className="mt-4 space-y-2 text-xs">
                  {product.dimensions && (
                    <div className="flex items-center justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500 font-medium">المقاسات المقترحة:</span>
                      <span className="text-stone-900 font-bold">{product.dimensions}</span>
                    </div>
                  )}
                  {product.woodType && (
                    <div className="flex items-center justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500 font-medium">نوعية الخشب:</span>
                      <span className="text-stone-900 font-bold">{product.woodType}</span>
                    </div>
                  )}
                  {product.fabricType && (
                    <div className="flex items-center justify-between py-1.5 border-b border-stone-100">
                      <span className="text-stone-500 font-medium">قماش التنجيد:</span>
                      <span className="text-stone-900 font-bold">{product.fabricType}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between py-1.5 border-b border-stone-100">
                    <span className="text-stone-500 font-medium">التوصيل والتركيب:</span>
                    <span className="text-emerald-700 font-bold">مجاني لجميع أنحاء المغرب</span>
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp and Call Actions */}
              <div className="pt-2 space-y-2.5">
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>تأكيد الطلب أو الاستفسار عبر الواتساب</span>
                </a>

                <a
                  href={`tel:${phone}`}
                  className="w-full py-2.5 px-4 rounded-xl border border-stone-300 hover:border-amber-600 text-stone-800 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <Phone className="w-4 h-4 text-amber-600" />
                  <span>اتصال هاتفي مباشر ({phone})</span>
                </a>
              </div>
            </div>
          </div>

          {/* Quick Inquiry Form inside Modal */}
          <div className="pt-4 border-t border-stone-200">
            <h4 className="text-sm font-bold text-stone-900 mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>أو اترك رقم هاتفك وسيتصل بك المعلم جواد Nazaré Tapisserie:</span>
            </h4>

            {submitSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-medium flex items-center gap-3">
                <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>تم إرسال طلبكم بنجاح! سيتصل بكم فريقنا هاتفياً في غضون دقائق.</span>
              </div>
            ) : (
              <form onSubmit={handleSubmitQuote} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  placeholder="اسمك الكامل *"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-white"
                />
                <input
                  type="tel"
                  required
                  placeholder="رقم الهاتف (الواتساب) *"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="px-3.5 py-2.5 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-white"
                />
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="py-2.5 px-4 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? "جاري الإرسال..." : "طلب اتصال مجاني"}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
