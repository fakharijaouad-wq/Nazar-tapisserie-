"use client";

import { useState } from "react";
import Link from "next/link";
import { Phone, Mail, MessageCircle, Menu, X, ShieldCheck, Sparkles, Sofa } from "lucide-react";

interface NavbarProps {
  phone?: string;
  email?: string;
  announcement?: string;
}

export default function Navbar({
  phone = "0631363887",
  email = "fakharijaouad@gmail.com",
  announcement = "✨ تفصيل حسب المقاس والطلب مع ضمان 5 سنوات وتوصيل وتركيب مجاني في جميع أنحاء المغرب ✨",
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Moroccan WhatsApp international format
  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    "السلام عليكم ورحمة الله، أتواصل معكم عبر موقع Nazaré Tapisserie للاستفسار وطلب تفصيل مفروشات."
  )}`;

  return (
    <header className="sticky top-0 z-50 w-full shadow-sm bg-white/95 backdrop-blur-md transition-all">
      {/* Top bar */}
      <div className="bg-stone-900 text-stone-200 text-xs py-2 px-4 border-b border-amber-900/40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-amber-300/95 font-medium text-center md:text-right">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{announcement}</span>
          </div>

          <div className="flex items-center gap-4 text-stone-300">
            <a
              href={`tel:${phone}`}
              dir="ltr"
              className="flex items-center gap-1.5 hover:text-amber-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>{phone}</span>
            </a>
            <span className="text-stone-600 hidden sm:inline">|</span>
            <a
              href={`mailto:${email}`}
              className="hidden sm:flex items-center gap-1.5 hover:text-amber-400 transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>{email}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-600 via-amber-700 to-amber-900 flex items-center justify-center text-white shadow-md shadow-amber-900/20 group-hover:scale-105 transition-transform">
              <Sofa className="w-6 h-6 text-amber-100" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-['Playfair_Display'] font-bold text-xl sm:text-2xl tracking-tight text-stone-900 group-hover:text-amber-700 transition-colors">
                  Nazaré
                </span>
                <span className="text-xs uppercase tracking-widest text-amber-600 font-semibold px-1.5 py-0.5 bg-amber-50 rounded border border-amber-200">
                  Tapisserie
                </span>
              </div>
              <p className="text-[11px] text-stone-500 font-medium">
                صناعة وتنجيد المفروشات المنزلية الراقية
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-stone-700">
            <Link href="/" className="hover:text-amber-700 transition-colors">
              الرئيسية
            </Link>
            <Link href="/#catalog" className="hover:text-amber-700 transition-colors">
              الكتالوج والأسعار
            </Link>
            <Link href="/#categories" className="hover:text-amber-700 transition-colors">
              الأقسام
            </Link>
            <Link href="/#craftsmanship" className="hover:text-amber-700 transition-colors">
              الجودة والضمان
            </Link>
            <Link href="/#custom-quote" className="hover:text-amber-700 transition-colors">
              طلب تفصيل مخصص
            </Link>
            <Link href="/#reviews" className="hover:text-amber-700 transition-colors">
              آراء العملاء
            </Link>
            <Link href="/#contact" className="hover:text-amber-700 transition-colors">
              تواصل معنا
            </Link>
          </nav>

          {/* Action Buttons */}
          <div className="hidden sm:flex items-center gap-2.5">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold px-3.5 py-2 rounded-xl shadow-sm transition-all hover:shadow hover:-translate-y-0.5"
            >
              <MessageCircle className="w-4 h-4" />
              <span>واتساب ورشة العمل</span>
            </a>

            <Link
              href="/admin"
              className="inline-flex items-center gap-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs sm:text-sm font-semibold px-3 py-2 rounded-xl transition-all border border-stone-200 hover:border-amber-300"
              title="لوحة التحكم للتعديل على الصور والأثمنة"
            >
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>لوحة التحكم</span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="flex sm:hidden items-center gap-2">
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-emerald-600 text-white"
            >
              <MessageCircle className="w-4 h-4" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-stone-100 text-stone-700 hover:bg-stone-200 transition-colors"
              aria-label="القائمة"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-5 py-4 space-y-3 animate-in slide-in-from-top">
          <div className="flex flex-col space-y-2.5 text-base font-semibold text-stone-800">
            <Link
              href="/"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              الرئيسية
            </Link>
            <Link
              href="/#catalog"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              الكتالوج والأسعار المقترحة
            </Link>
            <Link
              href="/#categories"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              أقسام المفروشات
            </Link>
            <Link
              href="/#craftsmanship"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              معايير الجودة والضمان
            </Link>
            <Link
              href="/#custom-quote"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              طلب تفصيل حسب المقاس
            </Link>
            <Link
              href="/#reviews"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              آراء وتجارب الزبناء
            </Link>
            <Link
              href="/#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-amber-700 border-b border-stone-100"
            >
              معلومات الاتصال
            </Link>
            <Link
              href="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-between py-2 text-amber-700 font-bold bg-amber-50 px-3 rounded-lg border border-amber-200"
            >
              <span>لوحة التحكم (تعديل الصور والأثمنة)</span>
              <ShieldCheck className="w-4 h-4" />
            </Link>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <a
              href={`tel:${phone}`}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-stone-900 text-white text-sm font-bold"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>اتصل هاتفياً: {phone}</span>
            </a>
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-bold"
            >
              <MessageCircle className="w-4 h-4" />
              <span>محادثة واتساب مباشرة</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
