"use client";

import { useState } from "react";
import { MessageCircle, Send, CheckCircle2, Ruler, Sofa, Bed, UtensilsCrossed, Armchair, Baby } from "lucide-react";

interface CustomQuoteSectionProps {
  phone?: string;
}

export default function CustomQuoteSection({ phone = "0631363887" }: CustomQuoteSectionProps) {
  const [selectedType, setSelectedType] = useState("كنبات وصالونات عصرية");
  const [name, setName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [city, setCity] = useState("الدار البيضاء");
  const [dimensions, setDimensions] = useState("");
  const [fabric, setFabric] = useState("مخمل مقاوم للبقع (Anti-taches)");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !clientPhone) return;

    setLoading(true);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: name,
          clientPhone,
          city,
          productTitle: selectedType,
          customDimensions: dimensions,
          preferredFabric: fabric,
          message: notes,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSuccess(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getDirectWaUrl = () => {
    const text = `السلام عليكم ورحمة الله، أنا ${name || "زبون"} من مدينة ${city}.
أود طلب تسعيرة وتفصيل مفروشات لدى شركة Nazaré Tapisserie:
- نوع المفروشات: ${selectedType}
- المقاسات: ${dimensions || "حسب الاستشارة"}
- نوع القماش المفضل: ${fabric}
${notes ? `- ملاحظات إضافية: ${notes}` : ""}`;
    return `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="custom-quote" className="py-16 sm:py-20 bg-stone-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-pattern-dark opacity-40 pointer-events-none" />
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Heading & Value props */}
          <div className="lg:col-span-5 space-y-6 text-right">
            <span className="text-xs font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3.5 py-1.5 rounded-full inline-block">
              تفصيل على المقاس 100%
            </span>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black leading-tight text-stone-100">
              صمم مفروشات بيتك كما تحلم وبالمقاس الدقيق لمساحتك
            </h2>

            <p className="text-sm sm:text-base text-stone-300 leading-relaxed">
              سواء كانت لديك صورة من Pinterest أو إنستغرام، أو فكرة خاصة لصالونك، أو غرفة نومك أو كراسي السفرة،
              ورشات <span className="text-amber-400 font-bold">Nazaré Tapisserie</span> تحول أفكارك إلى واقع متقن
              بأفضل المواد والأسعار المناسبة.
            </p>

            <div className="space-y-3 pt-2 text-xs sm:text-sm text-stone-300">
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  ✓
                </div>
                <span>أخذ المقاسات بدقة واستشارة لاختيار أفضل الأقمشة والألوان</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  ✓
                </div>
                <span>هيكل خشبي من خشب الزان الأحمر الرومي الصلب لضمان المتانة</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  ✓
                </div>
                <span>توصيل وتركيب مجاني في جميع أنحاء المملكة المغربية</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-stone-800/80 border border-stone-700/80 space-y-2">
              <span className="text-xs text-stone-400 block font-medium">للطلب المباشر والتحدث مع المعلم جواد:</span>
              <a
                href={getDirectWaUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <MessageCircle className="w-5 h-5" />
                <span>إرسال المواصفات مباشرة عبر الواتساب</span>
              </a>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="bg-stone-800/90 backdrop-blur-md rounded-3xl p-6 sm:p-8 border border-stone-700 shadow-2xl">
              <h3 className="text-lg sm:text-xl font-bold text-amber-300 mb-5 flex items-center gap-2">
                <Ruler className="w-5 h-5 text-amber-400" />
                <span>طلب تسعيرة وتفصيل مخصص</span>
              </h3>

              {success ? (
                <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-4">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                  <h4 className="text-lg font-bold text-white">تم استلام طلبكم بنجاح!</h4>
                  <p className="text-sm text-emerald-200">
                    شكراً لثقتكم بشركة Nazaré Tapisserie. سيتواصل معكم فريقنا هاتفياً في غضون وقت وجيز لتقديم الاقتراحات والمقاسات.
                  </p>
                  <a
                    href={getDirectWaUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-500 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>متابعة الطلب عبر الواتساب الآن</span>
                  </a>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Select Furniture Type */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-300 mb-2">
                      نوع المفروشات المطلوب:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      {[
                        { label: "كنبات وصالونات عصرية", icon: Sofa },
                        { label: "غرف نوم ماستر", icon: Bed },
                        { label: "غرف نوم الأطفال", icon: Baby },
                        { label: "كراسي طاولات الطعام", icon: UtensilsCrossed },
                        { label: "كراسي إضافية / فوطاي وبوف", icon: Armchair },
                        { label: "صالون مغربي تقليدي/عصري", icon: Sofa },
                      ].map((item) => (
                        <button
                          key={item.label}
                          type="button"
                          onClick={() => setSelectedType(item.label)}
                          className={`p-2.5 rounded-xl border text-right transition-all flex items-center gap-2 ${
                            selectedType === item.label
                              ? "bg-amber-600 border-amber-500 text-white font-bold"
                              : "bg-stone-900/60 border-stone-700 text-stone-300 hover:border-amber-400"
                          }`}
                        >
                          <item.icon className="w-4 h-4 shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Customer Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block text-xs font-semibold text-stone-300 mb-1">
                        الاسم الكامل *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="مثال: محمد العلوي"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/80 border border-stone-700 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-300 mb-1">
                        رقم الهاتف (الواتساب) *
                      </label>
                      <input
                        type="tel"
                        required
                        value={clientPhone}
                        onChange={(e) => setClientPhone(e.target.value)}
                        placeholder="مثال: 0631363887"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/80 border border-stone-700 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* City & Dimensions */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-stone-300 mb-1">
                        المدينة
                      </label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/80 border border-stone-700 text-white text-sm focus:outline-none focus:border-amber-500"
                      >
                        <option value="الدار البيضاء">الدار البيضاء</option>
                        <option value="الرباط / سلا">الرباط / سلا</option>
                        <option value="مراكش">مراكش</option>
                        <option value="طنجة / تطوان">طنجة / تطوان</option>
                        <option value="فاس / مكناس">فاس / مكناس</option>
                        <option value="أكادير">أكادير</option>
                        <option value="القنيطرة">القنيطرة</option>
                        <option value="وجدة / الناظور">وجدة / الناظور</option>
                        <option value="مدينة أخرى">مدينة أخرى بالمغرب</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-300 mb-1">
                        المقاسات التقريبية (اختياري)
                      </label>
                      <input
                        type="text"
                        value={dimensions}
                        onChange={(e) => setDimensions(e.target.value)}
                        placeholder="مثال: 3 أمتار × 2.40 متر"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/80 border border-stone-700 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Fabric Preference */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-300 mb-1">
                      نوع القماش المفضل
                    </label>
                    <select
                      value={fabric}
                      onChange={(e) => setFabric(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/80 border border-stone-700 text-white text-sm focus:outline-none focus:border-amber-500"
                    >
                      <option value="مخمل مقاوم للبقع (Anti-taches)">مخمل ناعم مقاوم للبقع والسوائل (Anti-taches)</option>
                      <option value="كتان طبيعي راقي (Lin de luxe)">كتان طبيعي فخم (Lin de luxe)</option>
                      <option value="قماش بوكلي حديث (Bouclé moderne)">قماش بوكلي حديث وعصري (Bouclé)</option>
                      <option value="جلد أو سيميلي فاخر">جلد صناعي أو طبيعي معالج</option>
                      <option value="قماش صالون مغربي تركي">أقمشة الصالون المغربي الفاخرة</option>
                      <option value="استشارة لاختيار الأنسب">أفضل استشارتكم لتحديد النوع الأنسب</option>
                    </select>
                  </div>

                  {/* Message/Notes */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-300 mb-1">
                      ملاحظات أو مواصفات خاصة
                    </label>
                    <textarea
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="اذكر أي تفاصيل إضافية مثل اللون، شكل الأرجل، أو إذا كان لديك تصميم خاص..."
                      className="w-full px-3.5 py-2 rounded-xl bg-stone-900/80 border border-stone-700 text-white placeholder-stone-500 text-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Submit button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-3.5 px-6 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 disabled:opacity-50 transition-all"
                    >
                      <Send className="w-4 h-4" />
                      <span>{loading ? "جاري الإرسال..." : "إرسال طلب التسعيرة المجاني"}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
