"use client";

import Link from "next/link";
import { Phone, MessageCircle, ShieldCheck, Award, Ruler, Truck, Sparkles, ChevronDown } from "lucide-react";

interface HeroProps {
  phone?: string;
  email?: string;
  title?: string;
  subtitle?: string;
}

export default function Hero({
  phone = "0631363887",
  email = "fakharijaouad@gmail.com",
  title = "صناعة وتنجيد المفروشات المنزلية الفاخرة والكنبات وغرف النوم",
  subtitle = "شركة Nazaré Tapisserie رائدة في صناعة وتنجيد الكنبات العصرية، غرف النوم الماستر والأطفال، كراسي طاولات الطعام وكراسي الصالونات بأجود أخشاب الزان والأقمشة المقاومة للبقع.",
}: HeroProps) {
  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    "السلام عليكم، أود الاستفسار عن تفصيل مفروشات لدى شركة Nazaré Tapisserie."
  )}`;

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-stone-900 via-stone-900 to-stone-950 text-white pt-12 pb-20 lg:py-24">
      {/* Background Glow & Pattern */}
      <div className="absolute inset-0 bg-pattern-dark opacity-30 pointer-events-none" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-amber-700/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Right Column (Arabic RTL: Text content) */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-right">
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-semibold">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>ورشات Nazaré Tapisserie — حرفية مغربية وإتقان عالمي</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-stone-100 leading-[1.25] tracking-tight">
              {title}
            </h1>

            {/* Subtitle */}
            <p className="text-stone-300 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto lg:mx-0">
              {subtitle}
            </p>

            {/* Specialties Pills */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1 text-xs sm:text-sm font-medium">
              <span className="px-3 py-1 rounded-lg bg-stone-800/80 border border-stone-700 text-amber-200">
                🛋️ الكنبات والصالونات العصرية
              </span>
              <span className="px-3 py-1 rounded-lg bg-stone-800/80 border border-stone-700 text-amber-200">
                🛏️ غرف النوم الماستر
              </span>
              <span className="px-3 py-1 rounded-lg bg-stone-800/80 border border-stone-700 text-amber-200">
                🧸 غرف نوم الأطفال
              </span>
              <span className="px-3 py-1 rounded-lg bg-stone-800/80 border border-stone-700 text-amber-200">
                🪑 كراسي طاولات الطعام
              </span>
              <span className="px-3 py-1 rounded-lg bg-stone-800/80 border border-stone-700 text-amber-200">
                💺 الفوطايات والكراسي الإضافية
              </span>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-4">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-sm sm:text-base shadow-lg shadow-emerald-950/40 hover:-translate-y-0.5 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>طلب تسعيرة عبر الواتساب</span>
              </a>

              <a
                href={`tel:${phone}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm sm:text-base shadow-lg shadow-amber-950/30 hover:-translate-y-0.5 transition-all"
              >
                <Phone className="w-5 h-5" />
                <span>اتصال مباشر: {phone}</span>
              </a>

              <Link
                href="#catalog"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-stone-800/90 hover:bg-stone-700 text-stone-200 font-semibold text-sm sm:text-base border border-stone-700 transition-colors"
              >
                <span>تصفح الكتالوج</span>
                <ChevronDown className="w-4 h-4 text-amber-400" />
              </Link>
            </div>

            {/* Guarantee and Quality Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-stone-800 text-stone-300 text-xs">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>ضمان 5 سنوات كاملة</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400 shrink-0" />
                <span>خشب زان أحمر أصيل</span>
              </div>
              <div className="flex items-center gap-2">
                <Ruler className="w-4 h-4 text-amber-400 shrink-0" />
                <span>تفصيل مخصص بالمقاس</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>توصيل وتركيب مجاني</span>
              </div>
            </div>
          </div>

          {/* Left Column: Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Image with border and soft shadow */}
              <div className="relative rounded-2xl overflow-hidden border-2 border-amber-600/30 shadow-2xl shadow-amber-950/50 group">
                <img
                  src="https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
                  alt="صالون فخم Nazaré Tapisserie"
                  className="w-full h-80 sm:h-96 object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-950/20 to-transparent" />

                <div className="absolute bottom-4 right-4 left-4 p-4 rounded-xl bg-stone-900/80 backdrop-blur-md border border-amber-500/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[11px] text-amber-300 font-bold uppercase tracking-wider">
                        صالون زاوية رويال
                      </span>
                      <h4 className="text-white font-bold text-sm">تفصيل فاخر حسب مقاسك</h4>
                    </div>
                    <div className="text-left">
                      <span className="text-[10px] text-stone-400 block">الثمن المقترح</span>
                      <span className="text-amber-400 font-black text-sm">6,800 د.م.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Secondary Floating Card */}
              <div className="absolute -top-4 -right-4 bg-stone-900/90 backdrop-blur-md border border-amber-500/40 text-stone-100 p-3 rounded-xl shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-600 flex items-center justify-center text-white">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">100% صنع يدوي متقن</div>
                  <div className="text-[10px] text-stone-400">حرفيون محترفون بالتنجيد</div>
                </div>
              </div>

              {/* Floating Bottom Card */}
              <div className="absolute -bottom-5 -left-3 bg-stone-900/90 backdrop-blur-md border border-emerald-500/40 text-stone-100 p-3 rounded-xl shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">رد فوري على الواتساب</div>
                  <div className="text-[10px] text-emerald-400">0631363887</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
