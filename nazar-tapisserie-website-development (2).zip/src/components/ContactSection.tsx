"use client";

import { Phone, Mail, MessageCircle, MapPin, Clock, Truck, ShieldCheck } from "lucide-react";

interface ContactSectionProps {
  phone?: string;
  email?: string;
  address?: string;
  workingHours?: string;
}

export default function ContactSection({
  phone = "0631363887",
  email = "fakharijaouad@gmail.com",
  address = "المغرب - ورشات الصنعة الرفيعة والتوصيل والتركيب لجميع المدن",
  workingHours = "طيلة أيام الأسبوع من 9:00 صباحاً حتى 20:30 مساءً",
}: ContactSectionProps) {
  const cleanPhone = phone.replace(/\D/g, "");
  const waNumber = cleanPhone.startsWith("0") ? "212" + cleanPhone.substring(1) : cleanPhone;
  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    "السلام عليكم، أتواصل معكم عبر موقع Nazaré Tapisserie للاستفسار وطلب تفصيل مفروشات."
  )}`;

  return (
    <section id="contact" className="py-16 sm:py-20 bg-stone-100 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold text-amber-700 bg-amber-100 px-3 py-1 rounded-full border border-amber-200">
            تواصل معنا مباشرة
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900">
            يسعدنا استقبال اتصالاتكم واستفساراتكم
          </h2>
          <p className="text-sm text-stone-600">
            نحن رهن إشارتكم لتقديم المشورة، معاينة النماذج، وتحديد المقاسات في أي وقت
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Phone Card */}
          <div className="p-6 rounded-2xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-lg transition-all text-center space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900">الهاتف والواتساب</h3>
              <p className="text-xs text-stone-500">متاح للمكالمات والاستفسارات الفورية</p>
              <div className="text-lg font-black text-amber-700 font-mono" dir="ltr">
                {phone}
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-3 border-t border-stone-100">
              <a
                href={`tel:${phone}`}
                className="w-full py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال هاتفي</span>
              </a>
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>محادثة واتساب</span>
              </a>
            </div>
          </div>

          {/* Email Card */}
          <div className="p-6 rounded-2xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-lg transition-all text-center space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900">البريد الإلكتروني</h3>
              <p className="text-xs text-stone-500">للمشاريع، التصاميم والمراسلات الرسمية</p>
              <div className="text-sm font-bold text-stone-800 break-all" dir="ltr">
                {email}
              </div>
            </div>

            <div className="pt-3 border-t border-stone-100">
              <a
                href={`mailto:${email}`}
                className="w-full py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>إرسال رسالة بريد</span>
              </a>
            </div>
          </div>

          {/* Service & Coverage Card */}
          <div className="p-6 rounded-2xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-lg transition-all text-center space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-stone-900">أوقات العمل والتوصيل</h3>
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex items-center justify-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  <span>{workingHours}</span>
                </div>
                <div className="flex items-center justify-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-amber-600" />
                  <span>توصيل وتركيب لكافة مدن المغرب</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-stone-100">
              <div className="p-2.5 rounded-xl bg-amber-50 text-amber-800 text-xs font-semibold border border-amber-200 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                <span>ضمان 5 سنوات على كافة الأعمال</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
