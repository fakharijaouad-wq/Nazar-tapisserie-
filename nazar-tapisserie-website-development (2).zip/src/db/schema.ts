import { pgTable, serial, varchar, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  titleFr: varchar("title_fr", { length: 255 }),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  category: varchar("category", { length: 100 }).notNull(), // 'sofas', 'bedrooms', 'kids_bedrooms', 'dining_chairs', 'accent_chairs'
  categoryNameAr: varchar("category_name_ar", { length: 100 }).notNull(),
  price: integer("price").notNull(), // suggested price in MAD
  originalPrice: integer("original_price"),
  pricePrefix: varchar("price_prefix", { length: 50 }).default("ابتداءً من"),
  imageUrl: text("image_url").notNull(),
  galleryUrls: text("gallery_urls").array(),
  description: text("description").notNull(),
  woodType: varchar("wood_type", { length: 255 }),
  fabricType: varchar("fabric_type", { length: 255 }),
  dimensions: varchar("dimensions", { length: 255 }),
  warrantyYears: integer("warranty_years").default(5),
  isFeatured: boolean("is_featured").default(false),
  badge: varchar("badge", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const quoteRequests = pgTable("quote_requests", {
  id: serial("id").primaryKey(),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  clientPhone: varchar("client_phone", { length: 100 }).notNull(),
  clientEmail: varchar("client_email", { length: 255 }),
  city: varchar("city", { length: 100 }),
  productId: integer("product_id"),
  productTitle: varchar("product_title", { length: 255 }),
  message: text("message"),
  customDimensions: varchar("custom_dimensions", { length: 255 }),
  preferredFabric: varchar("preferred_fabric", { length: 255 }),
  status: varchar("status", { length: 50 }).default("new"), // 'new', 'contacted', 'completed', 'cancelled'
  createdAt: timestamp("created_at").defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  companyName: varchar("company_name", { length: 255 }).default("Nazaré Tapisserie"),
  phone: varchar("phone", { length: 50 }).default("0631363887"),
  email: varchar("email", { length: 255 }).default("fakharijaouad@gmail.com"),
  address: text("address").default("المغرب - خدمة التوصيل والتركيب لجميع المدن"),
  announcement: text("announcement").default("تخفيضات خاصة وتوصيل وتركيب مجاني في جميع أنحاء المملكة مع ضمان 5 سنوات"),
  workingHours: varchar("working_hours", { length: 255 }).default("يومياً من 9:00 صباحاً إلى 20:30 مساءً"),
  heroTitle: text("hero_title").default("صناعة المفروشات الفاخرة والكنبات وغرف النوم حسب مقاسك وذوقك"),
  heroSubtitle: text("hero_subtitle").default("شركة Nazaré Tapisserie متخصصة في صناعة وتنجيد الكنبات العصرية، غرف النوم الماستر والأطفال، كراسي طاولات الطعام وكراسي الصالونات بأجود أنواع الخشب والأقمشة."),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  clientName: varchar("client_name", { length: 255 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  rating: integer("rating").default(5),
  comment: text("comment").notNull(),
  productName: varchar("product_name", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type QuoteRequest = typeof quoteRequests.$inferSelect;
export type SiteSettings = typeof siteSettings.$inferSelect;
export type Review = typeof reviews.$inferSelect;
